﻿namespace Minefield
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.label40 = new System.Windows.Forms.Label();
            this.label41 = new System.Windows.Forms.Label();
            this.label42 = new System.Windows.Forms.Label();
            this.label43 = new System.Windows.Forms.Label();
            this.label44 = new System.Windows.Forms.Label();
            this.label45 = new System.Windows.Forms.Label();
            this.label46 = new System.Windows.Forms.Label();
            this.label47 = new System.Windows.Forms.Label();
            this.label48 = new System.Windows.Forms.Label();
            this.label49 = new System.Windows.Forms.Label();
            this.label50 = new System.Windows.Forms.Label();
            this.label51 = new System.Windows.Forms.Label();
            this.label52 = new System.Windows.Forms.Label();
            this.label53 = new System.Windows.Forms.Label();
            this.label54 = new System.Windows.Forms.Label();
            this.label55 = new System.Windows.Forms.Label();
            this.label56 = new System.Windows.Forms.Label();
            this.label57 = new System.Windows.Forms.Label();
            this.label58 = new System.Windows.Forms.Label();
            this.label59 = new System.Windows.Forms.Label();
            this.label60 = new System.Windows.Forms.Label();
            this.label61 = new System.Windows.Forms.Label();
            this.label62 = new System.Windows.Forms.Label();
            this.label63 = new System.Windows.Forms.Label();
            this.label64 = new System.Windows.Forms.Label();
            this.label65 = new System.Windows.Forms.Label();
            this.label66 = new System.Windows.Forms.Label();
            this.label67 = new System.Windows.Forms.Label();
            this.label68 = new System.Windows.Forms.Label();
            this.label69 = new System.Windows.Forms.Label();
            this.label70 = new System.Windows.Forms.Label();
            this.label71 = new System.Windows.Forms.Label();
            this.label72 = new System.Windows.Forms.Label();
            this.label73 = new System.Windows.Forms.Label();
            this.label74 = new System.Windows.Forms.Label();
            this.label75 = new System.Windows.Forms.Label();
            this.label76 = new System.Windows.Forms.Label();
            this.label77 = new System.Windows.Forms.Label();
            this.label78 = new System.Windows.Forms.Label();
            this.label79 = new System.Windows.Forms.Label();
            this.label80 = new System.Windows.Forms.Label();
            this.label81 = new System.Windows.Forms.Label();
            this.label82 = new System.Windows.Forms.Label();
            this.label83 = new System.Windows.Forms.Label();
            this.label84 = new System.Windows.Forms.Label();
            this.label85 = new System.Windows.Forms.Label();
            this.label86 = new System.Windows.Forms.Label();
            this.label87 = new System.Windows.Forms.Label();
            this.label88 = new System.Windows.Forms.Label();
            this.label89 = new System.Windows.Forms.Label();
            this.label90 = new System.Windows.Forms.Label();
            this.label91 = new System.Windows.Forms.Label();
            this.label92 = new System.Windows.Forms.Label();
            this.label93 = new System.Windows.Forms.Label();
            this.label94 = new System.Windows.Forms.Label();
            this.label95 = new System.Windows.Forms.Label();
            this.label96 = new System.Windows.Forms.Label();
            this.label97 = new System.Windows.Forms.Label();
            this.label98 = new System.Windows.Forms.Label();
            this.label99 = new System.Windows.Forms.Label();
            this.label100 = new System.Windows.Forms.Label();
            this.label101 = new System.Windows.Forms.Label();
            this.label102 = new System.Windows.Forms.Label();
            this.label103 = new System.Windows.Forms.Label();
            this.label104 = new System.Windows.Forms.Label();
            this.label105 = new System.Windows.Forms.Label();
            this.label106 = new System.Windows.Forms.Label();
            this.label107 = new System.Windows.Forms.Label();
            this.label108 = new System.Windows.Forms.Label();
            this.label109 = new System.Windows.Forms.Label();
            this.label110 = new System.Windows.Forms.Label();
            this.label111 = new System.Windows.Forms.Label();
            this.label112 = new System.Windows.Forms.Label();
            this.label113 = new System.Windows.Forms.Label();
            this.label114 = new System.Windows.Forms.Label();
            this.label115 = new System.Windows.Forms.Label();
            this.label116 = new System.Windows.Forms.Label();
            this.label117 = new System.Windows.Forms.Label();
            this.label118 = new System.Windows.Forms.Label();
            this.label119 = new System.Windows.Forms.Label();
            this.label120 = new System.Windows.Forms.Label();
            this.label121 = new System.Windows.Forms.Label();
            this.label122 = new System.Windows.Forms.Label();
            this.label123 = new System.Windows.Forms.Label();
            this.label124 = new System.Windows.Forms.Label();
            this.label125 = new System.Windows.Forms.Label();
            this.label126 = new System.Windows.Forms.Label();
            this.label127 = new System.Windows.Forms.Label();
            this.label128 = new System.Windows.Forms.Label();
            this.label129 = new System.Windows.Forms.Label();
            this.label130 = new System.Windows.Forms.Label();
            this.label131 = new System.Windows.Forms.Label();
            this.label132 = new System.Windows.Forms.Label();
            this.label133 = new System.Windows.Forms.Label();
            this.label134 = new System.Windows.Forms.Label();
            this.label135 = new System.Windows.Forms.Label();
            this.label136 = new System.Windows.Forms.Label();
            this.label137 = new System.Windows.Forms.Label();
            this.label138 = new System.Windows.Forms.Label();
            this.label139 = new System.Windows.Forms.Label();
            this.label140 = new System.Windows.Forms.Label();
            this.label141 = new System.Windows.Forms.Label();
            this.label142 = new System.Windows.Forms.Label();
            this.label143 = new System.Windows.Forms.Label();
            this.label144 = new System.Windows.Forms.Label();
            this.label145 = new System.Windows.Forms.Label();
            this.label146 = new System.Windows.Forms.Label();
            this.label147 = new System.Windows.Forms.Label();
            this.label148 = new System.Windows.Forms.Label();
            this.label149 = new System.Windows.Forms.Label();
            this.label150 = new System.Windows.Forms.Label();
            this.label151 = new System.Windows.Forms.Label();
            this.label152 = new System.Windows.Forms.Label();
            this.label153 = new System.Windows.Forms.Label();
            this.label154 = new System.Windows.Forms.Label();
            this.label155 = new System.Windows.Forms.Label();
            this.label156 = new System.Windows.Forms.Label();
            this.label157 = new System.Windows.Forms.Label();
            this.label158 = new System.Windows.Forms.Label();
            this.label159 = new System.Windows.Forms.Label();
            this.label160 = new System.Windows.Forms.Label();
            this.label161 = new System.Windows.Forms.Label();
            this.label162 = new System.Windows.Forms.Label();
            this.label163 = new System.Windows.Forms.Label();
            this.label164 = new System.Windows.Forms.Label();
            this.label165 = new System.Windows.Forms.Label();
            this.label166 = new System.Windows.Forms.Label();
            this.label167 = new System.Windows.Forms.Label();
            this.label168 = new System.Windows.Forms.Label();
            this.label169 = new System.Windows.Forms.Label();
            this.label170 = new System.Windows.Forms.Label();
            this.label171 = new System.Windows.Forms.Label();
            this.label172 = new System.Windows.Forms.Label();
            this.label173 = new System.Windows.Forms.Label();
            this.label174 = new System.Windows.Forms.Label();
            this.label175 = new System.Windows.Forms.Label();
            this.label176 = new System.Windows.Forms.Label();
            this.label177 = new System.Windows.Forms.Label();
            this.label178 = new System.Windows.Forms.Label();
            this.label179 = new System.Windows.Forms.Label();
            this.label180 = new System.Windows.Forms.Label();
            this.label181 = new System.Windows.Forms.Label();
            this.label182 = new System.Windows.Forms.Label();
            this.label183 = new System.Windows.Forms.Label();
            this.label184 = new System.Windows.Forms.Label();
            this.label185 = new System.Windows.Forms.Label();
            this.label186 = new System.Windows.Forms.Label();
            this.label187 = new System.Windows.Forms.Label();
            this.label188 = new System.Windows.Forms.Label();
            this.label189 = new System.Windows.Forms.Label();
            this.label190 = new System.Windows.Forms.Label();
            this.label191 = new System.Windows.Forms.Label();
            this.label192 = new System.Windows.Forms.Label();
            this.label193 = new System.Windows.Forms.Label();
            this.label194 = new System.Windows.Forms.Label();
            this.label195 = new System.Windows.Forms.Label();
            this.label196 = new System.Windows.Forms.Label();
            this.label197 = new System.Windows.Forms.Label();
            this.label198 = new System.Windows.Forms.Label();
            this.label199 = new System.Windows.Forms.Label();
            this.label200 = new System.Windows.Forms.Label();
            this.label201 = new System.Windows.Forms.Label();
            this.label202 = new System.Windows.Forms.Label();
            this.label203 = new System.Windows.Forms.Label();
            this.label204 = new System.Windows.Forms.Label();
            this.label205 = new System.Windows.Forms.Label();
            this.label206 = new System.Windows.Forms.Label();
            this.label207 = new System.Windows.Forms.Label();
            this.label208 = new System.Windows.Forms.Label();
            this.label209 = new System.Windows.Forms.Label();
            this.label210 = new System.Windows.Forms.Label();
            this.label211 = new System.Windows.Forms.Label();
            this.label212 = new System.Windows.Forms.Label();
            this.label213 = new System.Windows.Forms.Label();
            this.label214 = new System.Windows.Forms.Label();
            this.label215 = new System.Windows.Forms.Label();
            this.label216 = new System.Windows.Forms.Label();
            this.label217 = new System.Windows.Forms.Label();
            this.label218 = new System.Windows.Forms.Label();
            this.label219 = new System.Windows.Forms.Label();
            this.label220 = new System.Windows.Forms.Label();
            this.label221 = new System.Windows.Forms.Label();
            this.label222 = new System.Windows.Forms.Label();
            this.label223 = new System.Windows.Forms.Label();
            this.label224 = new System.Windows.Forms.Label();
            this.label225 = new System.Windows.Forms.Label();
            this.label226 = new System.Windows.Forms.Label();
            this.label227 = new System.Windows.Forms.Label();
            this.label228 = new System.Windows.Forms.Label();
            this.label229 = new System.Windows.Forms.Label();
            this.label230 = new System.Windows.Forms.Label();
            this.label231 = new System.Windows.Forms.Label();
            this.label232 = new System.Windows.Forms.Label();
            this.label233 = new System.Windows.Forms.Label();
            this.label234 = new System.Windows.Forms.Label();
            this.label235 = new System.Windows.Forms.Label();
            this.label236 = new System.Windows.Forms.Label();
            this.label237 = new System.Windows.Forms.Label();
            this.label238 = new System.Windows.Forms.Label();
            this.label239 = new System.Windows.Forms.Label();
            this.label240 = new System.Windows.Forms.Label();
            this.label241 = new System.Windows.Forms.Label();
            this.label242 = new System.Windows.Forms.Label();
            this.label243 = new System.Windows.Forms.Label();
            this.label244 = new System.Windows.Forms.Label();
            this.label245 = new System.Windows.Forms.Label();
            this.label246 = new System.Windows.Forms.Label();
            this.label247 = new System.Windows.Forms.Label();
            this.label248 = new System.Windows.Forms.Label();
            this.label249 = new System.Windows.Forms.Label();
            this.label250 = new System.Windows.Forms.Label();
            this.label251 = new System.Windows.Forms.Label();
            this.label252 = new System.Windows.Forms.Label();
            this.label253 = new System.Windows.Forms.Label();
            this.label254 = new System.Windows.Forms.Label();
            this.label255 = new System.Windows.Forms.Label();
            this.label256 = new System.Windows.Forms.Label();
            this.label257 = new System.Windows.Forms.Label();
            this.label258 = new System.Windows.Forms.Label();
            this.label259 = new System.Windows.Forms.Label();
            this.label260 = new System.Windows.Forms.Label();
            this.label261 = new System.Windows.Forms.Label();
            this.label262 = new System.Windows.Forms.Label();
            this.label263 = new System.Windows.Forms.Label();
            this.label264 = new System.Windows.Forms.Label();
            this.label265 = new System.Windows.Forms.Label();
            this.label266 = new System.Windows.Forms.Label();
            this.label267 = new System.Windows.Forms.Label();
            this.label268 = new System.Windows.Forms.Label();
            this.label269 = new System.Windows.Forms.Label();
            this.label270 = new System.Windows.Forms.Label();
            this.label271 = new System.Windows.Forms.Label();
            this.label272 = new System.Windows.Forms.Label();
            this.label273 = new System.Windows.Forms.Label();
            this.label274 = new System.Windows.Forms.Label();
            this.label275 = new System.Windows.Forms.Label();
            this.label276 = new System.Windows.Forms.Label();
            this.label277 = new System.Windows.Forms.Label();
            this.label278 = new System.Windows.Forms.Label();
            this.label279 = new System.Windows.Forms.Label();
            this.label280 = new System.Windows.Forms.Label();
            this.label281 = new System.Windows.Forms.Label();
            this.label282 = new System.Windows.Forms.Label();
            this.label283 = new System.Windows.Forms.Label();
            this.label284 = new System.Windows.Forms.Label();
            this.label285 = new System.Windows.Forms.Label();
            this.label286 = new System.Windows.Forms.Label();
            this.label287 = new System.Windows.Forms.Label();
            this.label288 = new System.Windows.Forms.Label();
            this.label289 = new System.Windows.Forms.Label();
            this.label290 = new System.Windows.Forms.Label();
            this.label291 = new System.Windows.Forms.Label();
            this.label292 = new System.Windows.Forms.Label();
            this.label293 = new System.Windows.Forms.Label();
            this.label294 = new System.Windows.Forms.Label();
            this.label295 = new System.Windows.Forms.Label();
            this.label296 = new System.Windows.Forms.Label();
            this.label297 = new System.Windows.Forms.Label();
            this.label298 = new System.Windows.Forms.Label();
            this.label299 = new System.Windows.Forms.Label();
            this.label300 = new System.Windows.Forms.Label();
            this.label301 = new System.Windows.Forms.Label();
            this.label302 = new System.Windows.Forms.Label();
            this.label303 = new System.Windows.Forms.Label();
            this.label304 = new System.Windows.Forms.Label();
            this.label305 = new System.Windows.Forms.Label();
            this.label306 = new System.Windows.Forms.Label();
            this.label307 = new System.Windows.Forms.Label();
            this.label308 = new System.Windows.Forms.Label();
            this.label309 = new System.Windows.Forms.Label();
            this.label310 = new System.Windows.Forms.Label();
            this.label311 = new System.Windows.Forms.Label();
            this.label312 = new System.Windows.Forms.Label();
            this.label313 = new System.Windows.Forms.Label();
            this.label314 = new System.Windows.Forms.Label();
            this.label315 = new System.Windows.Forms.Label();
            this.label316 = new System.Windows.Forms.Label();
            this.label317 = new System.Windows.Forms.Label();
            this.label318 = new System.Windows.Forms.Label();
            this.label319 = new System.Windows.Forms.Label();
            this.label320 = new System.Windows.Forms.Label();
            this.label321 = new System.Windows.Forms.Label();
            this.label322 = new System.Windows.Forms.Label();
            this.label323 = new System.Windows.Forms.Label();
            this.label324 = new System.Windows.Forms.Label();
            this.label325 = new System.Windows.Forms.Label();
            this.label326 = new System.Windows.Forms.Label();
            this.label327 = new System.Windows.Forms.Label();
            this.label328 = new System.Windows.Forms.Label();
            this.label329 = new System.Windows.Forms.Label();
            this.label330 = new System.Windows.Forms.Label();
            this.label331 = new System.Windows.Forms.Label();
            this.label332 = new System.Windows.Forms.Label();
            this.label333 = new System.Windows.Forms.Label();
            this.label334 = new System.Windows.Forms.Label();
            this.label335 = new System.Windows.Forms.Label();
            this.label336 = new System.Windows.Forms.Label();
            this.label337 = new System.Windows.Forms.Label();
            this.label338 = new System.Windows.Forms.Label();
            this.label339 = new System.Windows.Forms.Label();
            this.label340 = new System.Windows.Forms.Label();
            this.label341 = new System.Windows.Forms.Label();
            this.label342 = new System.Windows.Forms.Label();
            this.label343 = new System.Windows.Forms.Label();
            this.label344 = new System.Windows.Forms.Label();
            this.label345 = new System.Windows.Forms.Label();
            this.label346 = new System.Windows.Forms.Label();
            this.label347 = new System.Windows.Forms.Label();
            this.label348 = new System.Windows.Forms.Label();
            this.label349 = new System.Windows.Forms.Label();
            this.label350 = new System.Windows.Forms.Label();
            this.label351 = new System.Windows.Forms.Label();
            this.label352 = new System.Windows.Forms.Label();
            this.label353 = new System.Windows.Forms.Label();
            this.label354 = new System.Windows.Forms.Label();
            this.label355 = new System.Windows.Forms.Label();
            this.label356 = new System.Windows.Forms.Label();
            this.label357 = new System.Windows.Forms.Label();
            this.label358 = new System.Windows.Forms.Label();
            this.label359 = new System.Windows.Forms.Label();
            this.label360 = new System.Windows.Forms.Label();
            this.label361 = new System.Windows.Forms.Label();
            this.label362 = new System.Windows.Forms.Label();
            this.label363 = new System.Windows.Forms.Label();
            this.label364 = new System.Windows.Forms.Label();
            this.label365 = new System.Windows.Forms.Label();
            this.label366 = new System.Windows.Forms.Label();
            this.label367 = new System.Windows.Forms.Label();
            this.label368 = new System.Windows.Forms.Label();
            this.label369 = new System.Windows.Forms.Label();
            this.label370 = new System.Windows.Forms.Label();
            this.label371 = new System.Windows.Forms.Label();
            this.label372 = new System.Windows.Forms.Label();
            this.label373 = new System.Windows.Forms.Label();
            this.label374 = new System.Windows.Forms.Label();
            this.label375 = new System.Windows.Forms.Label();
            this.label376 = new System.Windows.Forms.Label();
            this.label377 = new System.Windows.Forms.Label();
            this.label378 = new System.Windows.Forms.Label();
            this.label379 = new System.Windows.Forms.Label();
            this.label380 = new System.Windows.Forms.Label();
            this.label381 = new System.Windows.Forms.Label();
            this.label382 = new System.Windows.Forms.Label();
            this.label383 = new System.Windows.Forms.Label();
            this.label384 = new System.Windows.Forms.Label();
            this.label385 = new System.Windows.Forms.Label();
            this.label386 = new System.Windows.Forms.Label();
            this.label387 = new System.Windows.Forms.Label();
            this.label388 = new System.Windows.Forms.Label();
            this.label389 = new System.Windows.Forms.Label();
            this.label390 = new System.Windows.Forms.Label();
            this.label391 = new System.Windows.Forms.Label();
            this.label392 = new System.Windows.Forms.Label();
            this.label393 = new System.Windows.Forms.Label();
            this.label394 = new System.Windows.Forms.Label();
            this.label395 = new System.Windows.Forms.Label();
            this.label396 = new System.Windows.Forms.Label();
            this.label397 = new System.Windows.Forms.Label();
            this.label398 = new System.Windows.Forms.Label();
            this.label399 = new System.Windows.Forms.Label();
            this.label400 = new System.Windows.Forms.Label();
            this.btnup = new System.Windows.Forms.Button();
            this.btnleft = new System.Windows.Forms.Button();
            this.btnright = new System.Windows.Forms.Button();
            this.btndown = new System.Windows.Forms.Button();
            this.lbldanger = new System.Windows.Forms.Label();
            this.lblstatus = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ControlDark;
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Controls.Add(this.label7);
            this.panel1.Controls.Add(this.label8);
            this.panel1.Controls.Add(this.label9);
            this.panel1.Controls.Add(this.label10);
            this.panel1.Controls.Add(this.label11);
            this.panel1.Controls.Add(this.label12);
            this.panel1.Controls.Add(this.label13);
            this.panel1.Controls.Add(this.label14);
            this.panel1.Controls.Add(this.label15);
            this.panel1.Controls.Add(this.label16);
            this.panel1.Controls.Add(this.label17);
            this.panel1.Controls.Add(this.label18);
            this.panel1.Controls.Add(this.label19);
            this.panel1.Controls.Add(this.label20);
            this.panel1.Controls.Add(this.label21);
            this.panel1.Controls.Add(this.label22);
            this.panel1.Controls.Add(this.label23);
            this.panel1.Controls.Add(this.label24);
            this.panel1.Controls.Add(this.label25);
            this.panel1.Controls.Add(this.label26);
            this.panel1.Controls.Add(this.label27);
            this.panel1.Controls.Add(this.label28);
            this.panel1.Controls.Add(this.label29);
            this.panel1.Controls.Add(this.label30);
            this.panel1.Controls.Add(this.label31);
            this.panel1.Controls.Add(this.label32);
            this.panel1.Controls.Add(this.label33);
            this.panel1.Controls.Add(this.label34);
            this.panel1.Controls.Add(this.label35);
            this.panel1.Controls.Add(this.label36);
            this.panel1.Controls.Add(this.label37);
            this.panel1.Controls.Add(this.label38);
            this.panel1.Controls.Add(this.label39);
            this.panel1.Controls.Add(this.label40);
            this.panel1.Controls.Add(this.label41);
            this.panel1.Controls.Add(this.label42);
            this.panel1.Controls.Add(this.label43);
            this.panel1.Controls.Add(this.label44);
            this.panel1.Controls.Add(this.label45);
            this.panel1.Controls.Add(this.label46);
            this.panel1.Controls.Add(this.label47);
            this.panel1.Controls.Add(this.label48);
            this.panel1.Controls.Add(this.label49);
            this.panel1.Controls.Add(this.label50);
            this.panel1.Controls.Add(this.label51);
            this.panel1.Controls.Add(this.label52);
            this.panel1.Controls.Add(this.label53);
            this.panel1.Controls.Add(this.label54);
            this.panel1.Controls.Add(this.label55);
            this.panel1.Controls.Add(this.label56);
            this.panel1.Controls.Add(this.label57);
            this.panel1.Controls.Add(this.label58);
            this.panel1.Controls.Add(this.label59);
            this.panel1.Controls.Add(this.label60);
            this.panel1.Controls.Add(this.label61);
            this.panel1.Controls.Add(this.label62);
            this.panel1.Controls.Add(this.label63);
            this.panel1.Controls.Add(this.label64);
            this.panel1.Controls.Add(this.label65);
            this.panel1.Controls.Add(this.label66);
            this.panel1.Controls.Add(this.label67);
            this.panel1.Controls.Add(this.label68);
            this.panel1.Controls.Add(this.label69);
            this.panel1.Controls.Add(this.label70);
            this.panel1.Controls.Add(this.label71);
            this.panel1.Controls.Add(this.label72);
            this.panel1.Controls.Add(this.label73);
            this.panel1.Controls.Add(this.label74);
            this.panel1.Controls.Add(this.label75);
            this.panel1.Controls.Add(this.label76);
            this.panel1.Controls.Add(this.label77);
            this.panel1.Controls.Add(this.label78);
            this.panel1.Controls.Add(this.label79);
            this.panel1.Controls.Add(this.label80);
            this.panel1.Controls.Add(this.label81);
            this.panel1.Controls.Add(this.label82);
            this.panel1.Controls.Add(this.label83);
            this.panel1.Controls.Add(this.label84);
            this.panel1.Controls.Add(this.label85);
            this.panel1.Controls.Add(this.label86);
            this.panel1.Controls.Add(this.label87);
            this.panel1.Controls.Add(this.label88);
            this.panel1.Controls.Add(this.label89);
            this.panel1.Controls.Add(this.label90);
            this.panel1.Controls.Add(this.label91);
            this.panel1.Controls.Add(this.label92);
            this.panel1.Controls.Add(this.label93);
            this.panel1.Controls.Add(this.label94);
            this.panel1.Controls.Add(this.label95);
            this.panel1.Controls.Add(this.label96);
            this.panel1.Controls.Add(this.label97);
            this.panel1.Controls.Add(this.label98);
            this.panel1.Controls.Add(this.label99);
            this.panel1.Controls.Add(this.label100);
            this.panel1.Controls.Add(this.label101);
            this.panel1.Controls.Add(this.label102);
            this.panel1.Controls.Add(this.label103);
            this.panel1.Controls.Add(this.label104);
            this.panel1.Controls.Add(this.label105);
            this.panel1.Controls.Add(this.label106);
            this.panel1.Controls.Add(this.label107);
            this.panel1.Controls.Add(this.label108);
            this.panel1.Controls.Add(this.label109);
            this.panel1.Controls.Add(this.label110);
            this.panel1.Controls.Add(this.label111);
            this.panel1.Controls.Add(this.label112);
            this.panel1.Controls.Add(this.label113);
            this.panel1.Controls.Add(this.label114);
            this.panel1.Controls.Add(this.label115);
            this.panel1.Controls.Add(this.label116);
            this.panel1.Controls.Add(this.label117);
            this.panel1.Controls.Add(this.label118);
            this.panel1.Controls.Add(this.label119);
            this.panel1.Controls.Add(this.label120);
            this.panel1.Controls.Add(this.label121);
            this.panel1.Controls.Add(this.label122);
            this.panel1.Controls.Add(this.label123);
            this.panel1.Controls.Add(this.label124);
            this.panel1.Controls.Add(this.label125);
            this.panel1.Controls.Add(this.label126);
            this.panel1.Controls.Add(this.label127);
            this.panel1.Controls.Add(this.label128);
            this.panel1.Controls.Add(this.label129);
            this.panel1.Controls.Add(this.label130);
            this.panel1.Controls.Add(this.label131);
            this.panel1.Controls.Add(this.label132);
            this.panel1.Controls.Add(this.label133);
            this.panel1.Controls.Add(this.label134);
            this.panel1.Controls.Add(this.label135);
            this.panel1.Controls.Add(this.label136);
            this.panel1.Controls.Add(this.label137);
            this.panel1.Controls.Add(this.label138);
            this.panel1.Controls.Add(this.label139);
            this.panel1.Controls.Add(this.label140);
            this.panel1.Controls.Add(this.label141);
            this.panel1.Controls.Add(this.label142);
            this.panel1.Controls.Add(this.label143);
            this.panel1.Controls.Add(this.label144);
            this.panel1.Controls.Add(this.label145);
            this.panel1.Controls.Add(this.label146);
            this.panel1.Controls.Add(this.label147);
            this.panel1.Controls.Add(this.label148);
            this.panel1.Controls.Add(this.label149);
            this.panel1.Controls.Add(this.label150);
            this.panel1.Controls.Add(this.label151);
            this.panel1.Controls.Add(this.label152);
            this.panel1.Controls.Add(this.label153);
            this.panel1.Controls.Add(this.label154);
            this.panel1.Controls.Add(this.label155);
            this.panel1.Controls.Add(this.label156);
            this.panel1.Controls.Add(this.label157);
            this.panel1.Controls.Add(this.label158);
            this.panel1.Controls.Add(this.label159);
            this.panel1.Controls.Add(this.label160);
            this.panel1.Controls.Add(this.label161);
            this.panel1.Controls.Add(this.label162);
            this.panel1.Controls.Add(this.label163);
            this.panel1.Controls.Add(this.label164);
            this.panel1.Controls.Add(this.label165);
            this.panel1.Controls.Add(this.label166);
            this.panel1.Controls.Add(this.label167);
            this.panel1.Controls.Add(this.label168);
            this.panel1.Controls.Add(this.label169);
            this.panel1.Controls.Add(this.label170);
            this.panel1.Controls.Add(this.label171);
            this.panel1.Controls.Add(this.label172);
            this.panel1.Controls.Add(this.label173);
            this.panel1.Controls.Add(this.label174);
            this.panel1.Controls.Add(this.label175);
            this.panel1.Controls.Add(this.label176);
            this.panel1.Controls.Add(this.label177);
            this.panel1.Controls.Add(this.label178);
            this.panel1.Controls.Add(this.label179);
            this.panel1.Controls.Add(this.label180);
            this.panel1.Controls.Add(this.label181);
            this.panel1.Controls.Add(this.label182);
            this.panel1.Controls.Add(this.label183);
            this.panel1.Controls.Add(this.label184);
            this.panel1.Controls.Add(this.label185);
            this.panel1.Controls.Add(this.label186);
            this.panel1.Controls.Add(this.label187);
            this.panel1.Controls.Add(this.label188);
            this.panel1.Controls.Add(this.label189);
            this.panel1.Controls.Add(this.label190);
            this.panel1.Controls.Add(this.label191);
            this.panel1.Controls.Add(this.label192);
            this.panel1.Controls.Add(this.label193);
            this.panel1.Controls.Add(this.label194);
            this.panel1.Controls.Add(this.label195);
            this.panel1.Controls.Add(this.label196);
            this.panel1.Controls.Add(this.label197);
            this.panel1.Controls.Add(this.label198);
            this.panel1.Controls.Add(this.label199);
            this.panel1.Controls.Add(this.label200);
            this.panel1.Controls.Add(this.label201);
            this.panel1.Controls.Add(this.label202);
            this.panel1.Controls.Add(this.label203);
            this.panel1.Controls.Add(this.label204);
            this.panel1.Controls.Add(this.label205);
            this.panel1.Controls.Add(this.label206);
            this.panel1.Controls.Add(this.label207);
            this.panel1.Controls.Add(this.label208);
            this.panel1.Controls.Add(this.label209);
            this.panel1.Controls.Add(this.label210);
            this.panel1.Controls.Add(this.label211);
            this.panel1.Controls.Add(this.label212);
            this.panel1.Controls.Add(this.label213);
            this.panel1.Controls.Add(this.label214);
            this.panel1.Controls.Add(this.label215);
            this.panel1.Controls.Add(this.label216);
            this.panel1.Controls.Add(this.label217);
            this.panel1.Controls.Add(this.label218);
            this.panel1.Controls.Add(this.label219);
            this.panel1.Controls.Add(this.label220);
            this.panel1.Controls.Add(this.label221);
            this.panel1.Controls.Add(this.label222);
            this.panel1.Controls.Add(this.label223);
            this.panel1.Controls.Add(this.label224);
            this.panel1.Controls.Add(this.label225);
            this.panel1.Controls.Add(this.label226);
            this.panel1.Controls.Add(this.label227);
            this.panel1.Controls.Add(this.label228);
            this.panel1.Controls.Add(this.label229);
            this.panel1.Controls.Add(this.label230);
            this.panel1.Controls.Add(this.label231);
            this.panel1.Controls.Add(this.label232);
            this.panel1.Controls.Add(this.label233);
            this.panel1.Controls.Add(this.label234);
            this.panel1.Controls.Add(this.label235);
            this.panel1.Controls.Add(this.label236);
            this.panel1.Controls.Add(this.label237);
            this.panel1.Controls.Add(this.label238);
            this.panel1.Controls.Add(this.label239);
            this.panel1.Controls.Add(this.label240);
            this.panel1.Controls.Add(this.label241);
            this.panel1.Controls.Add(this.label242);
            this.panel1.Controls.Add(this.label243);
            this.panel1.Controls.Add(this.label244);
            this.panel1.Controls.Add(this.label245);
            this.panel1.Controls.Add(this.label246);
            this.panel1.Controls.Add(this.label247);
            this.panel1.Controls.Add(this.label248);
            this.panel1.Controls.Add(this.label249);
            this.panel1.Controls.Add(this.label250);
            this.panel1.Controls.Add(this.label251);
            this.panel1.Controls.Add(this.label252);
            this.panel1.Controls.Add(this.label253);
            this.panel1.Controls.Add(this.label254);
            this.panel1.Controls.Add(this.label255);
            this.panel1.Controls.Add(this.label256);
            this.panel1.Controls.Add(this.label257);
            this.panel1.Controls.Add(this.label258);
            this.panel1.Controls.Add(this.label259);
            this.panel1.Controls.Add(this.label260);
            this.panel1.Controls.Add(this.label261);
            this.panel1.Controls.Add(this.label262);
            this.panel1.Controls.Add(this.label263);
            this.panel1.Controls.Add(this.label264);
            this.panel1.Controls.Add(this.label265);
            this.panel1.Controls.Add(this.label266);
            this.panel1.Controls.Add(this.label267);
            this.panel1.Controls.Add(this.label268);
            this.panel1.Controls.Add(this.label269);
            this.panel1.Controls.Add(this.label270);
            this.panel1.Controls.Add(this.label271);
            this.panel1.Controls.Add(this.label272);
            this.panel1.Controls.Add(this.label273);
            this.panel1.Controls.Add(this.label274);
            this.panel1.Controls.Add(this.label275);
            this.panel1.Controls.Add(this.label276);
            this.panel1.Controls.Add(this.label277);
            this.panel1.Controls.Add(this.label278);
            this.panel1.Controls.Add(this.label279);
            this.panel1.Controls.Add(this.label280);
            this.panel1.Controls.Add(this.label281);
            this.panel1.Controls.Add(this.label282);
            this.panel1.Controls.Add(this.label283);
            this.panel1.Controls.Add(this.label284);
            this.panel1.Controls.Add(this.label285);
            this.panel1.Controls.Add(this.label286);
            this.panel1.Controls.Add(this.label287);
            this.panel1.Controls.Add(this.label288);
            this.panel1.Controls.Add(this.label289);
            this.panel1.Controls.Add(this.label290);
            this.panel1.Controls.Add(this.label291);
            this.panel1.Controls.Add(this.label292);
            this.panel1.Controls.Add(this.label293);
            this.panel1.Controls.Add(this.label294);
            this.panel1.Controls.Add(this.label295);
            this.panel1.Controls.Add(this.label296);
            this.panel1.Controls.Add(this.label297);
            this.panel1.Controls.Add(this.label298);
            this.panel1.Controls.Add(this.label299);
            this.panel1.Controls.Add(this.label300);
            this.panel1.Controls.Add(this.label301);
            this.panel1.Controls.Add(this.label302);
            this.panel1.Controls.Add(this.label303);
            this.panel1.Controls.Add(this.label304);
            this.panel1.Controls.Add(this.label305);
            this.panel1.Controls.Add(this.label306);
            this.panel1.Controls.Add(this.label307);
            this.panel1.Controls.Add(this.label308);
            this.panel1.Controls.Add(this.label309);
            this.panel1.Controls.Add(this.label310);
            this.panel1.Controls.Add(this.label311);
            this.panel1.Controls.Add(this.label312);
            this.panel1.Controls.Add(this.label313);
            this.panel1.Controls.Add(this.label314);
            this.panel1.Controls.Add(this.label315);
            this.panel1.Controls.Add(this.label316);
            this.panel1.Controls.Add(this.label317);
            this.panel1.Controls.Add(this.label318);
            this.panel1.Controls.Add(this.label319);
            this.panel1.Controls.Add(this.label320);
            this.panel1.Controls.Add(this.label321);
            this.panel1.Controls.Add(this.label322);
            this.panel1.Controls.Add(this.label323);
            this.panel1.Controls.Add(this.label324);
            this.panel1.Controls.Add(this.label325);
            this.panel1.Controls.Add(this.label326);
            this.panel1.Controls.Add(this.label327);
            this.panel1.Controls.Add(this.label328);
            this.panel1.Controls.Add(this.label329);
            this.panel1.Controls.Add(this.label330);
            this.panel1.Controls.Add(this.label331);
            this.panel1.Controls.Add(this.label332);
            this.panel1.Controls.Add(this.label333);
            this.panel1.Controls.Add(this.label334);
            this.panel1.Controls.Add(this.label335);
            this.panel1.Controls.Add(this.label336);
            this.panel1.Controls.Add(this.label337);
            this.panel1.Controls.Add(this.label338);
            this.panel1.Controls.Add(this.label339);
            this.panel1.Controls.Add(this.label340);
            this.panel1.Controls.Add(this.label341);
            this.panel1.Controls.Add(this.label342);
            this.panel1.Controls.Add(this.label343);
            this.panel1.Controls.Add(this.label344);
            this.panel1.Controls.Add(this.label345);
            this.panel1.Controls.Add(this.label346);
            this.panel1.Controls.Add(this.label347);
            this.panel1.Controls.Add(this.label348);
            this.panel1.Controls.Add(this.label349);
            this.panel1.Controls.Add(this.label350);
            this.panel1.Controls.Add(this.label351);
            this.panel1.Controls.Add(this.label352);
            this.panel1.Controls.Add(this.label353);
            this.panel1.Controls.Add(this.label354);
            this.panel1.Controls.Add(this.label355);
            this.panel1.Controls.Add(this.label356);
            this.panel1.Controls.Add(this.label357);
            this.panel1.Controls.Add(this.label358);
            this.panel1.Controls.Add(this.label359);
            this.panel1.Controls.Add(this.label360);
            this.panel1.Controls.Add(this.label361);
            this.panel1.Controls.Add(this.label362);
            this.panel1.Controls.Add(this.label363);
            this.panel1.Controls.Add(this.label364);
            this.panel1.Controls.Add(this.label365);
            this.panel1.Controls.Add(this.label366);
            this.panel1.Controls.Add(this.label367);
            this.panel1.Controls.Add(this.label368);
            this.panel1.Controls.Add(this.label369);
            this.panel1.Controls.Add(this.label370);
            this.panel1.Controls.Add(this.label371);
            this.panel1.Controls.Add(this.label372);
            this.panel1.Controls.Add(this.label373);
            this.panel1.Controls.Add(this.label374);
            this.panel1.Controls.Add(this.label375);
            this.panel1.Controls.Add(this.label376);
            this.panel1.Controls.Add(this.label377);
            this.panel1.Controls.Add(this.label378);
            this.panel1.Controls.Add(this.label379);
            this.panel1.Controls.Add(this.label380);
            this.panel1.Controls.Add(this.label381);
            this.panel1.Controls.Add(this.label382);
            this.panel1.Controls.Add(this.label383);
            this.panel1.Controls.Add(this.label384);
            this.panel1.Controls.Add(this.label385);
            this.panel1.Controls.Add(this.label386);
            this.panel1.Controls.Add(this.label387);
            this.panel1.Controls.Add(this.label388);
            this.panel1.Controls.Add(this.label389);
            this.panel1.Controls.Add(this.label390);
            this.panel1.Controls.Add(this.label391);
            this.panel1.Controls.Add(this.label392);
            this.panel1.Controls.Add(this.label393);
            this.panel1.Controls.Add(this.label394);
            this.panel1.Controls.Add(this.label395);
            this.panel1.Controls.Add(this.label396);
            this.panel1.Controls.Add(this.label397);
            this.panel1.Controls.Add(this.label398);
            this.panel1.Controls.Add(this.label399);
            this.panel1.Controls.Add(this.label400);
            this.panel1.Location = new System.Drawing.Point(13, 13);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(400, 400);
            this.panel1.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label1.Location = new System.Drawing.Point(0, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(20, 20);
            this.label1.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label2.Location = new System.Drawing.Point(20, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(20, 20);
            this.label2.TabIndex = 2;
            // 
            // label3
            // 
            this.label3.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label3.Location = new System.Drawing.Point(40, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(20, 20);
            this.label3.TabIndex = 3;
            // 
            // label4
            // 
            this.label4.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label4.Location = new System.Drawing.Point(60, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(20, 20);
            this.label4.TabIndex = 4;
            // 
            // label5
            // 
            this.label5.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label5.Location = new System.Drawing.Point(80, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(20, 20);
            this.label5.TabIndex = 5;
            // 
            // label6
            // 
            this.label6.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label6.Location = new System.Drawing.Point(100, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(20, 20);
            this.label6.TabIndex = 6;
            // 
            // label7
            // 
            this.label7.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label7.Location = new System.Drawing.Point(120, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(20, 20);
            this.label7.TabIndex = 7;
            // 
            // label8
            // 
            this.label8.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label8.Location = new System.Drawing.Point(140, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(20, 20);
            this.label8.TabIndex = 8;
            // 
            // label9
            // 
            this.label9.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label9.Location = new System.Drawing.Point(160, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(20, 20);
            this.label9.TabIndex = 9;
            // 
            // label10
            // 
            this.label10.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label10.Location = new System.Drawing.Point(180, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(20, 20);
            this.label10.TabIndex = 10;
            // 
            // label11
            // 
            this.label11.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label11.Location = new System.Drawing.Point(200, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(20, 20);
            this.label11.TabIndex = 11;
            // 
            // label12
            // 
            this.label12.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label12.Location = new System.Drawing.Point(220, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(20, 20);
            this.label12.TabIndex = 12;
            // 
            // label13
            // 
            this.label13.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label13.Location = new System.Drawing.Point(240, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(20, 20);
            this.label13.TabIndex = 13;
            // 
            // label14
            // 
            this.label14.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label14.Location = new System.Drawing.Point(260, 0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(20, 20);
            this.label14.TabIndex = 14;
            // 
            // label15
            // 
            this.label15.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label15.Location = new System.Drawing.Point(280, 0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(20, 20);
            this.label15.TabIndex = 15;
            // 
            // label16
            // 
            this.label16.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label16.Location = new System.Drawing.Point(300, 0);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(20, 20);
            this.label16.TabIndex = 16;
            // 
            // label17
            // 
            this.label17.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label17.Location = new System.Drawing.Point(320, 0);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(20, 20);
            this.label17.TabIndex = 17;
            // 
            // label18
            // 
            this.label18.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label18.Location = new System.Drawing.Point(340, 0);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(20, 20);
            this.label18.TabIndex = 18;
            // 
            // label19
            // 
            this.label19.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label19.Location = new System.Drawing.Point(360, 0);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(20, 20);
            this.label19.TabIndex = 19;
            // 
            // label20
            // 
            this.label20.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label20.Location = new System.Drawing.Point(380, 0);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(20, 20);
            this.label20.TabIndex = 20;
            // 
            // label21
            // 
            this.label21.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label21.Location = new System.Drawing.Point(0, 20);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(20, 20);
            this.label21.TabIndex = 21;
            // 
            // label22
            // 
            this.label22.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label22.Location = new System.Drawing.Point(20, 20);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(20, 20);
            this.label22.TabIndex = 22;
            // 
            // label23
            // 
            this.label23.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label23.Location = new System.Drawing.Point(40, 20);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(20, 20);
            this.label23.TabIndex = 23;
            // 
            // label24
            // 
            this.label24.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label24.Location = new System.Drawing.Point(60, 20);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(20, 20);
            this.label24.TabIndex = 24;
            // 
            // label25
            // 
            this.label25.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label25.Location = new System.Drawing.Point(80, 20);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(20, 20);
            this.label25.TabIndex = 25;
            // 
            // label26
            // 
            this.label26.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label26.Location = new System.Drawing.Point(100, 20);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(20, 20);
            this.label26.TabIndex = 26;
            // 
            // label27
            // 
            this.label27.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label27.Location = new System.Drawing.Point(120, 20);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(20, 20);
            this.label27.TabIndex = 27;
            // 
            // label28
            // 
            this.label28.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label28.Location = new System.Drawing.Point(140, 20);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(20, 20);
            this.label28.TabIndex = 28;
            // 
            // label29
            // 
            this.label29.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label29.Location = new System.Drawing.Point(160, 20);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(20, 20);
            this.label29.TabIndex = 29;
            // 
            // label30
            // 
            this.label30.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label30.Location = new System.Drawing.Point(180, 20);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(20, 20);
            this.label30.TabIndex = 30;
            // 
            // label31
            // 
            this.label31.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label31.Location = new System.Drawing.Point(200, 20);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(20, 20);
            this.label31.TabIndex = 31;
            // 
            // label32
            // 
            this.label32.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label32.Location = new System.Drawing.Point(220, 20);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(20, 20);
            this.label32.TabIndex = 32;
            // 
            // label33
            // 
            this.label33.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label33.Location = new System.Drawing.Point(240, 20);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(20, 20);
            this.label33.TabIndex = 33;
            // 
            // label34
            // 
            this.label34.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label34.Location = new System.Drawing.Point(260, 20);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(20, 20);
            this.label34.TabIndex = 34;
            // 
            // label35
            // 
            this.label35.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label35.Location = new System.Drawing.Point(280, 20);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(20, 20);
            this.label35.TabIndex = 35;
            // 
            // label36
            // 
            this.label36.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label36.Location = new System.Drawing.Point(300, 20);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(20, 20);
            this.label36.TabIndex = 36;
            // 
            // label37
            // 
            this.label37.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label37.Location = new System.Drawing.Point(320, 20);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(20, 20);
            this.label37.TabIndex = 37;
            // 
            // label38
            // 
            this.label38.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label38.Location = new System.Drawing.Point(340, 20);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(20, 20);
            this.label38.TabIndex = 38;
            // 
            // label39
            // 
            this.label39.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label39.Location = new System.Drawing.Point(360, 20);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(20, 20);
            this.label39.TabIndex = 39;
            // 
            // label40
            // 
            this.label40.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label40.Location = new System.Drawing.Point(380, 20);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(20, 20);
            this.label40.TabIndex = 40;
            // 
            // label41
            // 
            this.label41.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label41.Location = new System.Drawing.Point(0, 40);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(20, 20);
            this.label41.TabIndex = 41;
            // 
            // label42
            // 
            this.label42.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label42.Location = new System.Drawing.Point(20, 40);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(20, 20);
            this.label42.TabIndex = 42;
            // 
            // label43
            // 
            this.label43.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label43.Location = new System.Drawing.Point(40, 40);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(20, 20);
            this.label43.TabIndex = 43;
            // 
            // label44
            // 
            this.label44.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label44.Location = new System.Drawing.Point(60, 40);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(20, 20);
            this.label44.TabIndex = 44;
            // 
            // label45
            // 
            this.label45.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label45.Location = new System.Drawing.Point(80, 40);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(20, 20);
            this.label45.TabIndex = 45;
            // 
            // label46
            // 
            this.label46.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label46.Location = new System.Drawing.Point(100, 40);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(20, 20);
            this.label46.TabIndex = 46;
            // 
            // label47
            // 
            this.label47.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label47.Location = new System.Drawing.Point(120, 40);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(20, 20);
            this.label47.TabIndex = 47;
            // 
            // label48
            // 
            this.label48.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label48.Location = new System.Drawing.Point(140, 40);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(20, 20);
            this.label48.TabIndex = 48;
            // 
            // label49
            // 
            this.label49.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label49.Location = new System.Drawing.Point(160, 40);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(20, 20);
            this.label49.TabIndex = 49;
            // 
            // label50
            // 
            this.label50.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label50.Location = new System.Drawing.Point(180, 40);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(20, 20);
            this.label50.TabIndex = 50;
            // 
            // label51
            // 
            this.label51.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label51.Location = new System.Drawing.Point(200, 40);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(20, 20);
            this.label51.TabIndex = 51;
            // 
            // label52
            // 
            this.label52.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label52.Location = new System.Drawing.Point(220, 40);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(20, 20);
            this.label52.TabIndex = 52;
            // 
            // label53
            // 
            this.label53.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label53.Location = new System.Drawing.Point(240, 40);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(20, 20);
            this.label53.TabIndex = 53;
            // 
            // label54
            // 
            this.label54.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label54.Location = new System.Drawing.Point(260, 40);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(20, 20);
            this.label54.TabIndex = 54;
            // 
            // label55
            // 
            this.label55.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label55.Location = new System.Drawing.Point(280, 40);
            this.label55.Name = "label55";
            this.label55.Size = new System.Drawing.Size(20, 20);
            this.label55.TabIndex = 55;
            // 
            // label56
            // 
            this.label56.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label56.Location = new System.Drawing.Point(300, 40);
            this.label56.Name = "label56";
            this.label56.Size = new System.Drawing.Size(20, 20);
            this.label56.TabIndex = 56;
            // 
            // label57
            // 
            this.label57.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label57.Location = new System.Drawing.Point(320, 40);
            this.label57.Name = "label57";
            this.label57.Size = new System.Drawing.Size(20, 20);
            this.label57.TabIndex = 57;
            // 
            // label58
            // 
            this.label58.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label58.Location = new System.Drawing.Point(340, 40);
            this.label58.Name = "label58";
            this.label58.Size = new System.Drawing.Size(20, 20);
            this.label58.TabIndex = 58;
            // 
            // label59
            // 
            this.label59.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label59.Location = new System.Drawing.Point(360, 40);
            this.label59.Name = "label59";
            this.label59.Size = new System.Drawing.Size(20, 20);
            this.label59.TabIndex = 59;
            // 
            // label60
            // 
            this.label60.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label60.Location = new System.Drawing.Point(380, 40);
            this.label60.Name = "label60";
            this.label60.Size = new System.Drawing.Size(20, 20);
            this.label60.TabIndex = 60;
            // 
            // label61
            // 
            this.label61.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label61.Location = new System.Drawing.Point(0, 60);
            this.label61.Name = "label61";
            this.label61.Size = new System.Drawing.Size(20, 20);
            this.label61.TabIndex = 61;
            // 
            // label62
            // 
            this.label62.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label62.Location = new System.Drawing.Point(20, 60);
            this.label62.Name = "label62";
            this.label62.Size = new System.Drawing.Size(20, 20);
            this.label62.TabIndex = 62;
            // 
            // label63
            // 
            this.label63.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label63.Location = new System.Drawing.Point(40, 60);
            this.label63.Name = "label63";
            this.label63.Size = new System.Drawing.Size(20, 20);
            this.label63.TabIndex = 63;
            // 
            // label64
            // 
            this.label64.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label64.Location = new System.Drawing.Point(60, 60);
            this.label64.Name = "label64";
            this.label64.Size = new System.Drawing.Size(20, 20);
            this.label64.TabIndex = 64;
            // 
            // label65
            // 
            this.label65.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label65.Location = new System.Drawing.Point(80, 60);
            this.label65.Name = "label65";
            this.label65.Size = new System.Drawing.Size(20, 20);
            this.label65.TabIndex = 65;
            // 
            // label66
            // 
            this.label66.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label66.Location = new System.Drawing.Point(100, 60);
            this.label66.Name = "label66";
            this.label66.Size = new System.Drawing.Size(20, 20);
            this.label66.TabIndex = 66;
            // 
            // label67
            // 
            this.label67.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label67.Location = new System.Drawing.Point(120, 60);
            this.label67.Name = "label67";
            this.label67.Size = new System.Drawing.Size(20, 20);
            this.label67.TabIndex = 67;
            // 
            // label68
            // 
            this.label68.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label68.Location = new System.Drawing.Point(140, 60);
            this.label68.Name = "label68";
            this.label68.Size = new System.Drawing.Size(20, 20);
            this.label68.TabIndex = 68;
            // 
            // label69
            // 
            this.label69.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label69.Location = new System.Drawing.Point(160, 60);
            this.label69.Name = "label69";
            this.label69.Size = new System.Drawing.Size(20, 20);
            this.label69.TabIndex = 69;
            // 
            // label70
            // 
            this.label70.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label70.Location = new System.Drawing.Point(180, 60);
            this.label70.Name = "label70";
            this.label70.Size = new System.Drawing.Size(20, 20);
            this.label70.TabIndex = 70;
            // 
            // label71
            // 
            this.label71.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label71.Location = new System.Drawing.Point(200, 60);
            this.label71.Name = "label71";
            this.label71.Size = new System.Drawing.Size(20, 20);
            this.label71.TabIndex = 71;
            // 
            // label72
            // 
            this.label72.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label72.Location = new System.Drawing.Point(220, 60);
            this.label72.Name = "label72";
            this.label72.Size = new System.Drawing.Size(20, 20);
            this.label72.TabIndex = 72;
            // 
            // label73
            // 
            this.label73.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label73.Location = new System.Drawing.Point(240, 60);
            this.label73.Name = "label73";
            this.label73.Size = new System.Drawing.Size(20, 20);
            this.label73.TabIndex = 73;
            // 
            // label74
            // 
            this.label74.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label74.Location = new System.Drawing.Point(260, 60);
            this.label74.Name = "label74";
            this.label74.Size = new System.Drawing.Size(20, 20);
            this.label74.TabIndex = 74;
            // 
            // label75
            // 
            this.label75.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label75.Location = new System.Drawing.Point(280, 60);
            this.label75.Name = "label75";
            this.label75.Size = new System.Drawing.Size(20, 20);
            this.label75.TabIndex = 75;
            // 
            // label76
            // 
            this.label76.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label76.Location = new System.Drawing.Point(300, 60);
            this.label76.Name = "label76";
            this.label76.Size = new System.Drawing.Size(20, 20);
            this.label76.TabIndex = 76;
            // 
            // label77
            // 
            this.label77.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label77.Location = new System.Drawing.Point(320, 60);
            this.label77.Name = "label77";
            this.label77.Size = new System.Drawing.Size(20, 20);
            this.label77.TabIndex = 77;
            // 
            // label78
            // 
            this.label78.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label78.Location = new System.Drawing.Point(340, 60);
            this.label78.Name = "label78";
            this.label78.Size = new System.Drawing.Size(20, 20);
            this.label78.TabIndex = 78;
            // 
            // label79
            // 
            this.label79.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label79.Location = new System.Drawing.Point(360, 60);
            this.label79.Name = "label79";
            this.label79.Size = new System.Drawing.Size(20, 20);
            this.label79.TabIndex = 79;
            // 
            // label80
            // 
            this.label80.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label80.Location = new System.Drawing.Point(380, 60);
            this.label80.Name = "label80";
            this.label80.Size = new System.Drawing.Size(20, 20);
            this.label80.TabIndex = 80;
            // 
            // label81
            // 
            this.label81.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label81.Location = new System.Drawing.Point(0, 80);
            this.label81.Name = "label81";
            this.label81.Size = new System.Drawing.Size(20, 20);
            this.label81.TabIndex = 81;
            // 
            // label82
            // 
            this.label82.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label82.Location = new System.Drawing.Point(20, 80);
            this.label82.Name = "label82";
            this.label82.Size = new System.Drawing.Size(20, 20);
            this.label82.TabIndex = 82;
            // 
            // label83
            // 
            this.label83.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label83.Location = new System.Drawing.Point(40, 80);
            this.label83.Name = "label83";
            this.label83.Size = new System.Drawing.Size(20, 20);
            this.label83.TabIndex = 83;
            // 
            // label84
            // 
            this.label84.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label84.Location = new System.Drawing.Point(60, 80);
            this.label84.Name = "label84";
            this.label84.Size = new System.Drawing.Size(20, 20);
            this.label84.TabIndex = 84;
            // 
            // label85
            // 
            this.label85.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label85.Location = new System.Drawing.Point(80, 80);
            this.label85.Name = "label85";
            this.label85.Size = new System.Drawing.Size(20, 20);
            this.label85.TabIndex = 85;
            // 
            // label86
            // 
            this.label86.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label86.Location = new System.Drawing.Point(100, 80);
            this.label86.Name = "label86";
            this.label86.Size = new System.Drawing.Size(20, 20);
            this.label86.TabIndex = 86;
            // 
            // label87
            // 
            this.label87.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label87.Location = new System.Drawing.Point(120, 80);
            this.label87.Name = "label87";
            this.label87.Size = new System.Drawing.Size(20, 20);
            this.label87.TabIndex = 87;
            // 
            // label88
            // 
            this.label88.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label88.Location = new System.Drawing.Point(140, 80);
            this.label88.Name = "label88";
            this.label88.Size = new System.Drawing.Size(20, 20);
            this.label88.TabIndex = 88;
            // 
            // label89
            // 
            this.label89.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label89.Location = new System.Drawing.Point(160, 80);
            this.label89.Name = "label89";
            this.label89.Size = new System.Drawing.Size(20, 20);
            this.label89.TabIndex = 89;
            // 
            // label90
            // 
            this.label90.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label90.Location = new System.Drawing.Point(180, 80);
            this.label90.Name = "label90";
            this.label90.Size = new System.Drawing.Size(20, 20);
            this.label90.TabIndex = 90;
            // 
            // label91
            // 
            this.label91.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label91.Location = new System.Drawing.Point(200, 80);
            this.label91.Name = "label91";
            this.label91.Size = new System.Drawing.Size(20, 20);
            this.label91.TabIndex = 91;
            // 
            // label92
            // 
            this.label92.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label92.Location = new System.Drawing.Point(220, 80);
            this.label92.Name = "label92";
            this.label92.Size = new System.Drawing.Size(20, 20);
            this.label92.TabIndex = 92;
            // 
            // label93
            // 
            this.label93.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label93.Location = new System.Drawing.Point(240, 80);
            this.label93.Name = "label93";
            this.label93.Size = new System.Drawing.Size(20, 20);
            this.label93.TabIndex = 93;
            // 
            // label94
            // 
            this.label94.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label94.Location = new System.Drawing.Point(260, 80);
            this.label94.Name = "label94";
            this.label94.Size = new System.Drawing.Size(20, 20);
            this.label94.TabIndex = 94;
            // 
            // label95
            // 
            this.label95.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label95.Location = new System.Drawing.Point(280, 80);
            this.label95.Name = "label95";
            this.label95.Size = new System.Drawing.Size(20, 20);
            this.label95.TabIndex = 95;
            // 
            // label96
            // 
            this.label96.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label96.Location = new System.Drawing.Point(300, 80);
            this.label96.Name = "label96";
            this.label96.Size = new System.Drawing.Size(20, 20);
            this.label96.TabIndex = 96;
            // 
            // label97
            // 
            this.label97.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label97.Location = new System.Drawing.Point(320, 80);
            this.label97.Name = "label97";
            this.label97.Size = new System.Drawing.Size(20, 20);
            this.label97.TabIndex = 97;
            // 
            // label98
            // 
            this.label98.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label98.Location = new System.Drawing.Point(340, 80);
            this.label98.Name = "label98";
            this.label98.Size = new System.Drawing.Size(20, 20);
            this.label98.TabIndex = 98;
            // 
            // label99
            // 
            this.label99.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label99.Location = new System.Drawing.Point(360, 80);
            this.label99.Name = "label99";
            this.label99.Size = new System.Drawing.Size(20, 20);
            this.label99.TabIndex = 99;
            // 
            // label100
            // 
            this.label100.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label100.Location = new System.Drawing.Point(380, 80);
            this.label100.Name = "label100";
            this.label100.Size = new System.Drawing.Size(20, 20);
            this.label100.TabIndex = 100;
            // 
            // label101
            // 
            this.label101.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label101.Location = new System.Drawing.Point(0, 100);
            this.label101.Name = "label101";
            this.label101.Size = new System.Drawing.Size(20, 20);
            this.label101.TabIndex = 101;
            // 
            // label102
            // 
            this.label102.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label102.Location = new System.Drawing.Point(20, 100);
            this.label102.Name = "label102";
            this.label102.Size = new System.Drawing.Size(20, 20);
            this.label102.TabIndex = 102;
            // 
            // label103
            // 
            this.label103.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label103.Location = new System.Drawing.Point(40, 100);
            this.label103.Name = "label103";
            this.label103.Size = new System.Drawing.Size(20, 20);
            this.label103.TabIndex = 103;
            // 
            // label104
            // 
            this.label104.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label104.Location = new System.Drawing.Point(60, 100);
            this.label104.Name = "label104";
            this.label104.Size = new System.Drawing.Size(20, 20);
            this.label104.TabIndex = 104;
            // 
            // label105
            // 
            this.label105.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label105.Location = new System.Drawing.Point(80, 100);
            this.label105.Name = "label105";
            this.label105.Size = new System.Drawing.Size(20, 20);
            this.label105.TabIndex = 105;
            // 
            // label106
            // 
            this.label106.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label106.Location = new System.Drawing.Point(100, 100);
            this.label106.Name = "label106";
            this.label106.Size = new System.Drawing.Size(20, 20);
            this.label106.TabIndex = 106;
            // 
            // label107
            // 
            this.label107.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label107.Location = new System.Drawing.Point(120, 100);
            this.label107.Name = "label107";
            this.label107.Size = new System.Drawing.Size(20, 20);
            this.label107.TabIndex = 107;
            // 
            // label108
            // 
            this.label108.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label108.Location = new System.Drawing.Point(140, 100);
            this.label108.Name = "label108";
            this.label108.Size = new System.Drawing.Size(20, 20);
            this.label108.TabIndex = 108;
            // 
            // label109
            // 
            this.label109.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label109.Location = new System.Drawing.Point(160, 100);
            this.label109.Name = "label109";
            this.label109.Size = new System.Drawing.Size(20, 20);
            this.label109.TabIndex = 109;
            // 
            // label110
            // 
            this.label110.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label110.Location = new System.Drawing.Point(180, 100);
            this.label110.Name = "label110";
            this.label110.Size = new System.Drawing.Size(20, 20);
            this.label110.TabIndex = 110;
            // 
            // label111
            // 
            this.label111.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label111.Location = new System.Drawing.Point(200, 100);
            this.label111.Name = "label111";
            this.label111.Size = new System.Drawing.Size(20, 20);
            this.label111.TabIndex = 111;
            // 
            // label112
            // 
            this.label112.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label112.Location = new System.Drawing.Point(220, 100);
            this.label112.Name = "label112";
            this.label112.Size = new System.Drawing.Size(20, 20);
            this.label112.TabIndex = 112;
            // 
            // label113
            // 
            this.label113.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label113.Location = new System.Drawing.Point(240, 100);
            this.label113.Name = "label113";
            this.label113.Size = new System.Drawing.Size(20, 20);
            this.label113.TabIndex = 113;
            // 
            // label114
            // 
            this.label114.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label114.Location = new System.Drawing.Point(260, 100);
            this.label114.Name = "label114";
            this.label114.Size = new System.Drawing.Size(20, 20);
            this.label114.TabIndex = 114;
            // 
            // label115
            // 
            this.label115.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label115.Location = new System.Drawing.Point(280, 100);
            this.label115.Name = "label115";
            this.label115.Size = new System.Drawing.Size(20, 20);
            this.label115.TabIndex = 115;
            // 
            // label116
            // 
            this.label116.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label116.Location = new System.Drawing.Point(300, 100);
            this.label116.Name = "label116";
            this.label116.Size = new System.Drawing.Size(20, 20);
            this.label116.TabIndex = 116;
            // 
            // label117
            // 
            this.label117.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label117.Location = new System.Drawing.Point(320, 100);
            this.label117.Name = "label117";
            this.label117.Size = new System.Drawing.Size(20, 20);
            this.label117.TabIndex = 117;
            // 
            // label118
            // 
            this.label118.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label118.Location = new System.Drawing.Point(340, 100);
            this.label118.Name = "label118";
            this.label118.Size = new System.Drawing.Size(20, 20);
            this.label118.TabIndex = 118;
            // 
            // label119
            // 
            this.label119.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label119.Location = new System.Drawing.Point(360, 100);
            this.label119.Name = "label119";
            this.label119.Size = new System.Drawing.Size(20, 20);
            this.label119.TabIndex = 119;
            // 
            // label120
            // 
            this.label120.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label120.Location = new System.Drawing.Point(380, 100);
            this.label120.Name = "label120";
            this.label120.Size = new System.Drawing.Size(20, 20);
            this.label120.TabIndex = 120;
            // 
            // label121
            // 
            this.label121.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label121.Location = new System.Drawing.Point(0, 120);
            this.label121.Name = "label121";
            this.label121.Size = new System.Drawing.Size(20, 20);
            this.label121.TabIndex = 121;
            // 
            // label122
            // 
            this.label122.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label122.Location = new System.Drawing.Point(20, 120);
            this.label122.Name = "label122";
            this.label122.Size = new System.Drawing.Size(20, 20);
            this.label122.TabIndex = 122;
            // 
            // label123
            // 
            this.label123.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label123.Location = new System.Drawing.Point(40, 120);
            this.label123.Name = "label123";
            this.label123.Size = new System.Drawing.Size(20, 20);
            this.label123.TabIndex = 123;
            // 
            // label124
            // 
            this.label124.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label124.Location = new System.Drawing.Point(60, 120);
            this.label124.Name = "label124";
            this.label124.Size = new System.Drawing.Size(20, 20);
            this.label124.TabIndex = 124;
            // 
            // label125
            // 
            this.label125.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label125.Location = new System.Drawing.Point(80, 120);
            this.label125.Name = "label125";
            this.label125.Size = new System.Drawing.Size(20, 20);
            this.label125.TabIndex = 125;
            // 
            // label126
            // 
            this.label126.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label126.Location = new System.Drawing.Point(100, 120);
            this.label126.Name = "label126";
            this.label126.Size = new System.Drawing.Size(20, 20);
            this.label126.TabIndex = 126;
            // 
            // label127
            // 
            this.label127.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label127.Location = new System.Drawing.Point(120, 120);
            this.label127.Name = "label127";
            this.label127.Size = new System.Drawing.Size(20, 20);
            this.label127.TabIndex = 127;
            // 
            // label128
            // 
            this.label128.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label128.Location = new System.Drawing.Point(140, 120);
            this.label128.Name = "label128";
            this.label128.Size = new System.Drawing.Size(20, 20);
            this.label128.TabIndex = 128;
            // 
            // label129
            // 
            this.label129.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label129.Location = new System.Drawing.Point(160, 120);
            this.label129.Name = "label129";
            this.label129.Size = new System.Drawing.Size(20, 20);
            this.label129.TabIndex = 129;
            // 
            // label130
            // 
            this.label130.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label130.Location = new System.Drawing.Point(180, 120);
            this.label130.Name = "label130";
            this.label130.Size = new System.Drawing.Size(20, 20);
            this.label130.TabIndex = 130;
            // 
            // label131
            // 
            this.label131.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label131.Location = new System.Drawing.Point(200, 120);
            this.label131.Name = "label131";
            this.label131.Size = new System.Drawing.Size(20, 20);
            this.label131.TabIndex = 131;
            // 
            // label132
            // 
            this.label132.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label132.Location = new System.Drawing.Point(220, 120);
            this.label132.Name = "label132";
            this.label132.Size = new System.Drawing.Size(20, 20);
            this.label132.TabIndex = 132;
            // 
            // label133
            // 
            this.label133.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label133.Location = new System.Drawing.Point(240, 120);
            this.label133.Name = "label133";
            this.label133.Size = new System.Drawing.Size(20, 20);
            this.label133.TabIndex = 133;
            // 
            // label134
            // 
            this.label134.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label134.Location = new System.Drawing.Point(260, 120);
            this.label134.Name = "label134";
            this.label134.Size = new System.Drawing.Size(20, 20);
            this.label134.TabIndex = 134;
            // 
            // label135
            // 
            this.label135.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label135.Location = new System.Drawing.Point(280, 120);
            this.label135.Name = "label135";
            this.label135.Size = new System.Drawing.Size(20, 20);
            this.label135.TabIndex = 135;
            // 
            // label136
            // 
            this.label136.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label136.Location = new System.Drawing.Point(300, 120);
            this.label136.Name = "label136";
            this.label136.Size = new System.Drawing.Size(20, 20);
            this.label136.TabIndex = 136;
            // 
            // label137
            // 
            this.label137.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label137.Location = new System.Drawing.Point(320, 120);
            this.label137.Name = "label137";
            this.label137.Size = new System.Drawing.Size(20, 20);
            this.label137.TabIndex = 137;
            // 
            // label138
            // 
            this.label138.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label138.Location = new System.Drawing.Point(340, 120);
            this.label138.Name = "label138";
            this.label138.Size = new System.Drawing.Size(20, 20);
            this.label138.TabIndex = 138;
            // 
            // label139
            // 
            this.label139.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label139.Location = new System.Drawing.Point(360, 120);
            this.label139.Name = "label139";
            this.label139.Size = new System.Drawing.Size(20, 20);
            this.label139.TabIndex = 139;
            // 
            // label140
            // 
            this.label140.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label140.Location = new System.Drawing.Point(380, 120);
            this.label140.Name = "label140";
            this.label140.Size = new System.Drawing.Size(20, 20);
            this.label140.TabIndex = 140;
            // 
            // label141
            // 
            this.label141.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label141.Location = new System.Drawing.Point(0, 140);
            this.label141.Name = "label141";
            this.label141.Size = new System.Drawing.Size(20, 20);
            this.label141.TabIndex = 141;
            // 
            // label142
            // 
            this.label142.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label142.Location = new System.Drawing.Point(20, 140);
            this.label142.Name = "label142";
            this.label142.Size = new System.Drawing.Size(20, 20);
            this.label142.TabIndex = 142;
            // 
            // label143
            // 
            this.label143.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label143.Location = new System.Drawing.Point(40, 140);
            this.label143.Name = "label143";
            this.label143.Size = new System.Drawing.Size(20, 20);
            this.label143.TabIndex = 143;
            // 
            // label144
            // 
            this.label144.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label144.Location = new System.Drawing.Point(60, 140);
            this.label144.Name = "label144";
            this.label144.Size = new System.Drawing.Size(20, 20);
            this.label144.TabIndex = 144;
            // 
            // label145
            // 
            this.label145.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label145.Location = new System.Drawing.Point(80, 140);
            this.label145.Name = "label145";
            this.label145.Size = new System.Drawing.Size(20, 20);
            this.label145.TabIndex = 145;
            // 
            // label146
            // 
            this.label146.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label146.Location = new System.Drawing.Point(100, 140);
            this.label146.Name = "label146";
            this.label146.Size = new System.Drawing.Size(20, 20);
            this.label146.TabIndex = 146;
            // 
            // label147
            // 
            this.label147.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label147.Location = new System.Drawing.Point(120, 140);
            this.label147.Name = "label147";
            this.label147.Size = new System.Drawing.Size(20, 20);
            this.label147.TabIndex = 147;
            // 
            // label148
            // 
            this.label148.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label148.Location = new System.Drawing.Point(140, 140);
            this.label148.Name = "label148";
            this.label148.Size = new System.Drawing.Size(20, 20);
            this.label148.TabIndex = 148;
            // 
            // label149
            // 
            this.label149.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label149.Location = new System.Drawing.Point(160, 140);
            this.label149.Name = "label149";
            this.label149.Size = new System.Drawing.Size(20, 20);
            this.label149.TabIndex = 149;
            // 
            // label150
            // 
            this.label150.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label150.Location = new System.Drawing.Point(180, 140);
            this.label150.Name = "label150";
            this.label150.Size = new System.Drawing.Size(20, 20);
            this.label150.TabIndex = 150;
            // 
            // label151
            // 
            this.label151.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label151.Location = new System.Drawing.Point(200, 140);
            this.label151.Name = "label151";
            this.label151.Size = new System.Drawing.Size(20, 20);
            this.label151.TabIndex = 151;
            // 
            // label152
            // 
            this.label152.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label152.Location = new System.Drawing.Point(220, 140);
            this.label152.Name = "label152";
            this.label152.Size = new System.Drawing.Size(20, 20);
            this.label152.TabIndex = 152;
            // 
            // label153
            // 
            this.label153.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label153.Location = new System.Drawing.Point(240, 140);
            this.label153.Name = "label153";
            this.label153.Size = new System.Drawing.Size(20, 20);
            this.label153.TabIndex = 153;
            // 
            // label154
            // 
            this.label154.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label154.Location = new System.Drawing.Point(260, 140);
            this.label154.Name = "label154";
            this.label154.Size = new System.Drawing.Size(20, 20);
            this.label154.TabIndex = 154;
            // 
            // label155
            // 
            this.label155.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label155.Location = new System.Drawing.Point(280, 140);
            this.label155.Name = "label155";
            this.label155.Size = new System.Drawing.Size(20, 20);
            this.label155.TabIndex = 155;
            // 
            // label156
            // 
            this.label156.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label156.Location = new System.Drawing.Point(300, 140);
            this.label156.Name = "label156";
            this.label156.Size = new System.Drawing.Size(20, 20);
            this.label156.TabIndex = 156;
            // 
            // label157
            // 
            this.label157.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label157.Location = new System.Drawing.Point(320, 140);
            this.label157.Name = "label157";
            this.label157.Size = new System.Drawing.Size(20, 20);
            this.label157.TabIndex = 157;
            // 
            // label158
            // 
            this.label158.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label158.Location = new System.Drawing.Point(340, 140);
            this.label158.Name = "label158";
            this.label158.Size = new System.Drawing.Size(20, 20);
            this.label158.TabIndex = 158;
            // 
            // label159
            // 
            this.label159.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label159.Location = new System.Drawing.Point(360, 140);
            this.label159.Name = "label159";
            this.label159.Size = new System.Drawing.Size(20, 20);
            this.label159.TabIndex = 159;
            // 
            // label160
            // 
            this.label160.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label160.Location = new System.Drawing.Point(380, 140);
            this.label160.Name = "label160";
            this.label160.Size = new System.Drawing.Size(20, 20);
            this.label160.TabIndex = 160;
            // 
            // label161
            // 
            this.label161.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label161.Location = new System.Drawing.Point(0, 160);
            this.label161.Name = "label161";
            this.label161.Size = new System.Drawing.Size(20, 20);
            this.label161.TabIndex = 161;
            // 
            // label162
            // 
            this.label162.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label162.Location = new System.Drawing.Point(20, 160);
            this.label162.Name = "label162";
            this.label162.Size = new System.Drawing.Size(20, 20);
            this.label162.TabIndex = 162;
            // 
            // label163
            // 
            this.label163.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label163.Location = new System.Drawing.Point(40, 160);
            this.label163.Name = "label163";
            this.label163.Size = new System.Drawing.Size(20, 20);
            this.label163.TabIndex = 163;
            // 
            // label164
            // 
            this.label164.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label164.Location = new System.Drawing.Point(60, 160);
            this.label164.Name = "label164";
            this.label164.Size = new System.Drawing.Size(20, 20);
            this.label164.TabIndex = 164;
            // 
            // label165
            // 
            this.label165.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label165.Location = new System.Drawing.Point(80, 160);
            this.label165.Name = "label165";
            this.label165.Size = new System.Drawing.Size(20, 20);
            this.label165.TabIndex = 165;
            // 
            // label166
            // 
            this.label166.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label166.Location = new System.Drawing.Point(100, 160);
            this.label166.Name = "label166";
            this.label166.Size = new System.Drawing.Size(20, 20);
            this.label166.TabIndex = 166;
            // 
            // label167
            // 
            this.label167.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label167.Location = new System.Drawing.Point(120, 160);
            this.label167.Name = "label167";
            this.label167.Size = new System.Drawing.Size(20, 20);
            this.label167.TabIndex = 167;
            // 
            // label168
            // 
            this.label168.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label168.Location = new System.Drawing.Point(140, 160);
            this.label168.Name = "label168";
            this.label168.Size = new System.Drawing.Size(20, 20);
            this.label168.TabIndex = 168;
            // 
            // label169
            // 
            this.label169.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label169.Location = new System.Drawing.Point(160, 160);
            this.label169.Name = "label169";
            this.label169.Size = new System.Drawing.Size(20, 20);
            this.label169.TabIndex = 169;
            // 
            // label170
            // 
            this.label170.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label170.Location = new System.Drawing.Point(180, 160);
            this.label170.Name = "label170";
            this.label170.Size = new System.Drawing.Size(20, 20);
            this.label170.TabIndex = 170;
            // 
            // label171
            // 
            this.label171.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label171.Location = new System.Drawing.Point(200, 160);
            this.label171.Name = "label171";
            this.label171.Size = new System.Drawing.Size(20, 20);
            this.label171.TabIndex = 171;
            // 
            // label172
            // 
            this.label172.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label172.Location = new System.Drawing.Point(220, 160);
            this.label172.Name = "label172";
            this.label172.Size = new System.Drawing.Size(20, 20);
            this.label172.TabIndex = 172;
            // 
            // label173
            // 
            this.label173.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label173.Location = new System.Drawing.Point(240, 160);
            this.label173.Name = "label173";
            this.label173.Size = new System.Drawing.Size(20, 20);
            this.label173.TabIndex = 173;
            // 
            // label174
            // 
            this.label174.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label174.Location = new System.Drawing.Point(260, 160);
            this.label174.Name = "label174";
            this.label174.Size = new System.Drawing.Size(20, 20);
            this.label174.TabIndex = 174;
            // 
            // label175
            // 
            this.label175.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label175.Location = new System.Drawing.Point(280, 160);
            this.label175.Name = "label175";
            this.label175.Size = new System.Drawing.Size(20, 20);
            this.label175.TabIndex = 175;
            // 
            // label176
            // 
            this.label176.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label176.Location = new System.Drawing.Point(300, 160);
            this.label176.Name = "label176";
            this.label176.Size = new System.Drawing.Size(20, 20);
            this.label176.TabIndex = 176;
            // 
            // label177
            // 
            this.label177.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label177.Location = new System.Drawing.Point(320, 160);
            this.label177.Name = "label177";
            this.label177.Size = new System.Drawing.Size(20, 20);
            this.label177.TabIndex = 177;
            // 
            // label178
            // 
            this.label178.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label178.Location = new System.Drawing.Point(340, 160);
            this.label178.Name = "label178";
            this.label178.Size = new System.Drawing.Size(20, 20);
            this.label178.TabIndex = 178;
            // 
            // label179
            // 
            this.label179.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label179.Location = new System.Drawing.Point(360, 160);
            this.label179.Name = "label179";
            this.label179.Size = new System.Drawing.Size(20, 20);
            this.label179.TabIndex = 179;
            // 
            // label180
            // 
            this.label180.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label180.Location = new System.Drawing.Point(380, 160);
            this.label180.Name = "label180";
            this.label180.Size = new System.Drawing.Size(20, 20);
            this.label180.TabIndex = 180;
            // 
            // label181
            // 
            this.label181.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label181.Location = new System.Drawing.Point(0, 180);
            this.label181.Name = "label181";
            this.label181.Size = new System.Drawing.Size(20, 20);
            this.label181.TabIndex = 181;
            // 
            // label182
            // 
            this.label182.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label182.Location = new System.Drawing.Point(20, 180);
            this.label182.Name = "label182";
            this.label182.Size = new System.Drawing.Size(20, 20);
            this.label182.TabIndex = 182;
            // 
            // label183
            // 
            this.label183.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label183.Location = new System.Drawing.Point(40, 180);
            this.label183.Name = "label183";
            this.label183.Size = new System.Drawing.Size(20, 20);
            this.label183.TabIndex = 183;
            // 
            // label184
            // 
            this.label184.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label184.Location = new System.Drawing.Point(60, 180);
            this.label184.Name = "label184";
            this.label184.Size = new System.Drawing.Size(20, 20);
            this.label184.TabIndex = 184;
            // 
            // label185
            // 
            this.label185.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label185.Location = new System.Drawing.Point(80, 180);
            this.label185.Name = "label185";
            this.label185.Size = new System.Drawing.Size(20, 20);
            this.label185.TabIndex = 185;
            // 
            // label186
            // 
            this.label186.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label186.Location = new System.Drawing.Point(100, 180);
            this.label186.Name = "label186";
            this.label186.Size = new System.Drawing.Size(20, 20);
            this.label186.TabIndex = 186;
            // 
            // label187
            // 
            this.label187.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label187.Location = new System.Drawing.Point(120, 180);
            this.label187.Name = "label187";
            this.label187.Size = new System.Drawing.Size(20, 20);
            this.label187.TabIndex = 187;
            // 
            // label188
            // 
            this.label188.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label188.Location = new System.Drawing.Point(140, 180);
            this.label188.Name = "label188";
            this.label188.Size = new System.Drawing.Size(20, 20);
            this.label188.TabIndex = 188;
            // 
            // label189
            // 
            this.label189.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label189.Location = new System.Drawing.Point(160, 180);
            this.label189.Name = "label189";
            this.label189.Size = new System.Drawing.Size(20, 20);
            this.label189.TabIndex = 189;
            // 
            // label190
            // 
            this.label190.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label190.Location = new System.Drawing.Point(180, 180);
            this.label190.Name = "label190";
            this.label190.Size = new System.Drawing.Size(20, 20);
            this.label190.TabIndex = 190;
            // 
            // label191
            // 
            this.label191.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label191.Location = new System.Drawing.Point(200, 180);
            this.label191.Name = "label191";
            this.label191.Size = new System.Drawing.Size(20, 20);
            this.label191.TabIndex = 191;
            // 
            // label192
            // 
            this.label192.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label192.Location = new System.Drawing.Point(220, 180);
            this.label192.Name = "label192";
            this.label192.Size = new System.Drawing.Size(20, 20);
            this.label192.TabIndex = 192;
            // 
            // label193
            // 
            this.label193.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label193.Location = new System.Drawing.Point(240, 180);
            this.label193.Name = "label193";
            this.label193.Size = new System.Drawing.Size(20, 20);
            this.label193.TabIndex = 193;
            // 
            // label194
            // 
            this.label194.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label194.Location = new System.Drawing.Point(260, 180);
            this.label194.Name = "label194";
            this.label194.Size = new System.Drawing.Size(20, 20);
            this.label194.TabIndex = 194;
            // 
            // label195
            // 
            this.label195.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label195.Location = new System.Drawing.Point(280, 180);
            this.label195.Name = "label195";
            this.label195.Size = new System.Drawing.Size(20, 20);
            this.label195.TabIndex = 195;
            // 
            // label196
            // 
            this.label196.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label196.Location = new System.Drawing.Point(300, 180);
            this.label196.Name = "label196";
            this.label196.Size = new System.Drawing.Size(20, 20);
            this.label196.TabIndex = 196;
            // 
            // label197
            // 
            this.label197.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label197.Location = new System.Drawing.Point(320, 180);
            this.label197.Name = "label197";
            this.label197.Size = new System.Drawing.Size(20, 20);
            this.label197.TabIndex = 197;
            // 
            // label198
            // 
            this.label198.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label198.Location = new System.Drawing.Point(340, 180);
            this.label198.Name = "label198";
            this.label198.Size = new System.Drawing.Size(20, 20);
            this.label198.TabIndex = 198;
            // 
            // label199
            // 
            this.label199.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label199.Location = new System.Drawing.Point(360, 180);
            this.label199.Name = "label199";
            this.label199.Size = new System.Drawing.Size(20, 20);
            this.label199.TabIndex = 199;
            // 
            // label200
            // 
            this.label200.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label200.Location = new System.Drawing.Point(380, 180);
            this.label200.Name = "label200";
            this.label200.Size = new System.Drawing.Size(20, 20);
            this.label200.TabIndex = 200;
            // 
            // label201
            // 
            this.label201.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label201.Location = new System.Drawing.Point(0, 200);
            this.label201.Name = "label201";
            this.label201.Size = new System.Drawing.Size(20, 20);
            this.label201.TabIndex = 201;
            // 
            // label202
            // 
            this.label202.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label202.Location = new System.Drawing.Point(20, 200);
            this.label202.Name = "label202";
            this.label202.Size = new System.Drawing.Size(20, 20);
            this.label202.TabIndex = 202;
            // 
            // label203
            // 
            this.label203.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label203.Location = new System.Drawing.Point(40, 200);
            this.label203.Name = "label203";
            this.label203.Size = new System.Drawing.Size(20, 20);
            this.label203.TabIndex = 203;
            // 
            // label204
            // 
            this.label204.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label204.Location = new System.Drawing.Point(60, 200);
            this.label204.Name = "label204";
            this.label204.Size = new System.Drawing.Size(20, 20);
            this.label204.TabIndex = 204;
            // 
            // label205
            // 
            this.label205.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label205.Location = new System.Drawing.Point(80, 200);
            this.label205.Name = "label205";
            this.label205.Size = new System.Drawing.Size(20, 20);
            this.label205.TabIndex = 205;
            // 
            // label206
            // 
            this.label206.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label206.Location = new System.Drawing.Point(100, 200);
            this.label206.Name = "label206";
            this.label206.Size = new System.Drawing.Size(20, 20);
            this.label206.TabIndex = 206;
            // 
            // label207
            // 
            this.label207.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label207.Location = new System.Drawing.Point(120, 200);
            this.label207.Name = "label207";
            this.label207.Size = new System.Drawing.Size(20, 20);
            this.label207.TabIndex = 207;
            // 
            // label208
            // 
            this.label208.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label208.Location = new System.Drawing.Point(140, 200);
            this.label208.Name = "label208";
            this.label208.Size = new System.Drawing.Size(20, 20);
            this.label208.TabIndex = 208;
            // 
            // label209
            // 
            this.label209.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label209.Location = new System.Drawing.Point(160, 200);
            this.label209.Name = "label209";
            this.label209.Size = new System.Drawing.Size(20, 20);
            this.label209.TabIndex = 209;
            // 
            // label210
            // 
            this.label210.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label210.Location = new System.Drawing.Point(180, 200);
            this.label210.Name = "label210";
            this.label210.Size = new System.Drawing.Size(20, 20);
            this.label210.TabIndex = 210;
            // 
            // label211
            // 
            this.label211.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label211.Location = new System.Drawing.Point(200, 200);
            this.label211.Name = "label211";
            this.label211.Size = new System.Drawing.Size(20, 20);
            this.label211.TabIndex = 211;
            // 
            // label212
            // 
            this.label212.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label212.Location = new System.Drawing.Point(220, 200);
            this.label212.Name = "label212";
            this.label212.Size = new System.Drawing.Size(20, 20);
            this.label212.TabIndex = 212;
            // 
            // label213
            // 
            this.label213.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label213.Location = new System.Drawing.Point(240, 200);
            this.label213.Name = "label213";
            this.label213.Size = new System.Drawing.Size(20, 20);
            this.label213.TabIndex = 213;
            // 
            // label214
            // 
            this.label214.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label214.Location = new System.Drawing.Point(260, 200);
            this.label214.Name = "label214";
            this.label214.Size = new System.Drawing.Size(20, 20);
            this.label214.TabIndex = 214;
            // 
            // label215
            // 
            this.label215.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label215.Location = new System.Drawing.Point(280, 200);
            this.label215.Name = "label215";
            this.label215.Size = new System.Drawing.Size(20, 20);
            this.label215.TabIndex = 215;
            // 
            // label216
            // 
            this.label216.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label216.Location = new System.Drawing.Point(300, 200);
            this.label216.Name = "label216";
            this.label216.Size = new System.Drawing.Size(20, 20);
            this.label216.TabIndex = 216;
            // 
            // label217
            // 
            this.label217.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label217.Location = new System.Drawing.Point(320, 200);
            this.label217.Name = "label217";
            this.label217.Size = new System.Drawing.Size(20, 20);
            this.label217.TabIndex = 217;
            // 
            // label218
            // 
            this.label218.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label218.Location = new System.Drawing.Point(340, 200);
            this.label218.Name = "label218";
            this.label218.Size = new System.Drawing.Size(20, 20);
            this.label218.TabIndex = 218;
            // 
            // label219
            // 
            this.label219.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label219.Location = new System.Drawing.Point(360, 200);
            this.label219.Name = "label219";
            this.label219.Size = new System.Drawing.Size(20, 20);
            this.label219.TabIndex = 219;
            // 
            // label220
            // 
            this.label220.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label220.Location = new System.Drawing.Point(380, 200);
            this.label220.Name = "label220";
            this.label220.Size = new System.Drawing.Size(20, 20);
            this.label220.TabIndex = 220;
            // 
            // label221
            // 
            this.label221.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label221.Location = new System.Drawing.Point(0, 220);
            this.label221.Name = "label221";
            this.label221.Size = new System.Drawing.Size(20, 20);
            this.label221.TabIndex = 221;
            // 
            // label222
            // 
            this.label222.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label222.Location = new System.Drawing.Point(20, 220);
            this.label222.Name = "label222";
            this.label222.Size = new System.Drawing.Size(20, 20);
            this.label222.TabIndex = 222;
            // 
            // label223
            // 
            this.label223.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label223.Location = new System.Drawing.Point(40, 220);
            this.label223.Name = "label223";
            this.label223.Size = new System.Drawing.Size(20, 20);
            this.label223.TabIndex = 223;
            // 
            // label224
            // 
            this.label224.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label224.Location = new System.Drawing.Point(60, 220);
            this.label224.Name = "label224";
            this.label224.Size = new System.Drawing.Size(20, 20);
            this.label224.TabIndex = 224;
            // 
            // label225
            // 
            this.label225.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label225.Location = new System.Drawing.Point(80, 220);
            this.label225.Name = "label225";
            this.label225.Size = new System.Drawing.Size(20, 20);
            this.label225.TabIndex = 225;
            // 
            // label226
            // 
            this.label226.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label226.Location = new System.Drawing.Point(100, 220);
            this.label226.Name = "label226";
            this.label226.Size = new System.Drawing.Size(20, 20);
            this.label226.TabIndex = 226;
            // 
            // label227
            // 
            this.label227.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label227.Location = new System.Drawing.Point(120, 220);
            this.label227.Name = "label227";
            this.label227.Size = new System.Drawing.Size(20, 20);
            this.label227.TabIndex = 227;
            // 
            // label228
            // 
            this.label228.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label228.Location = new System.Drawing.Point(140, 220);
            this.label228.Name = "label228";
            this.label228.Size = new System.Drawing.Size(20, 20);
            this.label228.TabIndex = 228;
            // 
            // label229
            // 
            this.label229.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label229.Location = new System.Drawing.Point(160, 220);
            this.label229.Name = "label229";
            this.label229.Size = new System.Drawing.Size(20, 20);
            this.label229.TabIndex = 229;
            // 
            // label230
            // 
            this.label230.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label230.Location = new System.Drawing.Point(180, 220);
            this.label230.Name = "label230";
            this.label230.Size = new System.Drawing.Size(20, 20);
            this.label230.TabIndex = 230;
            // 
            // label231
            // 
            this.label231.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label231.Location = new System.Drawing.Point(200, 220);
            this.label231.Name = "label231";
            this.label231.Size = new System.Drawing.Size(20, 20);
            this.label231.TabIndex = 231;
            // 
            // label232
            // 
            this.label232.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label232.Location = new System.Drawing.Point(220, 220);
            this.label232.Name = "label232";
            this.label232.Size = new System.Drawing.Size(20, 20);
            this.label232.TabIndex = 232;
            // 
            // label233
            // 
            this.label233.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label233.Location = new System.Drawing.Point(240, 220);
            this.label233.Name = "label233";
            this.label233.Size = new System.Drawing.Size(20, 20);
            this.label233.TabIndex = 233;
            // 
            // label234
            // 
            this.label234.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label234.Location = new System.Drawing.Point(260, 220);
            this.label234.Name = "label234";
            this.label234.Size = new System.Drawing.Size(20, 20);
            this.label234.TabIndex = 234;
            // 
            // label235
            // 
            this.label235.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label235.Location = new System.Drawing.Point(280, 220);
            this.label235.Name = "label235";
            this.label235.Size = new System.Drawing.Size(20, 20);
            this.label235.TabIndex = 235;
            // 
            // label236
            // 
            this.label236.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label236.Location = new System.Drawing.Point(300, 220);
            this.label236.Name = "label236";
            this.label236.Size = new System.Drawing.Size(20, 20);
            this.label236.TabIndex = 236;
            // 
            // label237
            // 
            this.label237.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label237.Location = new System.Drawing.Point(320, 220);
            this.label237.Name = "label237";
            this.label237.Size = new System.Drawing.Size(20, 20);
            this.label237.TabIndex = 237;
            // 
            // label238
            // 
            this.label238.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label238.Location = new System.Drawing.Point(340, 220);
            this.label238.Name = "label238";
            this.label238.Size = new System.Drawing.Size(20, 20);
            this.label238.TabIndex = 238;
            // 
            // label239
            // 
            this.label239.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label239.Location = new System.Drawing.Point(360, 220);
            this.label239.Name = "label239";
            this.label239.Size = new System.Drawing.Size(20, 20);
            this.label239.TabIndex = 239;
            // 
            // label240
            // 
            this.label240.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label240.Location = new System.Drawing.Point(380, 220);
            this.label240.Name = "label240";
            this.label240.Size = new System.Drawing.Size(20, 20);
            this.label240.TabIndex = 240;
            // 
            // label241
            // 
            this.label241.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label241.Location = new System.Drawing.Point(0, 240);
            this.label241.Name = "label241";
            this.label241.Size = new System.Drawing.Size(20, 20);
            this.label241.TabIndex = 241;
            // 
            // label242
            // 
            this.label242.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label242.Location = new System.Drawing.Point(20, 240);
            this.label242.Name = "label242";
            this.label242.Size = new System.Drawing.Size(20, 20);
            this.label242.TabIndex = 242;
            // 
            // label243
            // 
            this.label243.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label243.Location = new System.Drawing.Point(40, 240);
            this.label243.Name = "label243";
            this.label243.Size = new System.Drawing.Size(20, 20);
            this.label243.TabIndex = 243;
            // 
            // label244
            // 
            this.label244.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label244.Location = new System.Drawing.Point(60, 240);
            this.label244.Name = "label244";
            this.label244.Size = new System.Drawing.Size(20, 20);
            this.label244.TabIndex = 244;
            // 
            // label245
            // 
            this.label245.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label245.Location = new System.Drawing.Point(80, 240);
            this.label245.Name = "label245";
            this.label245.Size = new System.Drawing.Size(20, 20);
            this.label245.TabIndex = 245;
            // 
            // label246
            // 
            this.label246.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label246.Location = new System.Drawing.Point(100, 240);
            this.label246.Name = "label246";
            this.label246.Size = new System.Drawing.Size(20, 20);
            this.label246.TabIndex = 246;
            // 
            // label247
            // 
            this.label247.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label247.Location = new System.Drawing.Point(120, 240);
            this.label247.Name = "label247";
            this.label247.Size = new System.Drawing.Size(20, 20);
            this.label247.TabIndex = 247;
            // 
            // label248
            // 
            this.label248.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label248.Location = new System.Drawing.Point(140, 240);
            this.label248.Name = "label248";
            this.label248.Size = new System.Drawing.Size(20, 20);
            this.label248.TabIndex = 248;
            // 
            // label249
            // 
            this.label249.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label249.Location = new System.Drawing.Point(160, 240);
            this.label249.Name = "label249";
            this.label249.Size = new System.Drawing.Size(20, 20);
            this.label249.TabIndex = 249;
            // 
            // label250
            // 
            this.label250.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label250.Location = new System.Drawing.Point(180, 240);
            this.label250.Name = "label250";
            this.label250.Size = new System.Drawing.Size(20, 20);
            this.label250.TabIndex = 250;
            // 
            // label251
            // 
            this.label251.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label251.Location = new System.Drawing.Point(200, 240);
            this.label251.Name = "label251";
            this.label251.Size = new System.Drawing.Size(20, 20);
            this.label251.TabIndex = 251;
            // 
            // label252
            // 
            this.label252.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label252.Location = new System.Drawing.Point(220, 240);
            this.label252.Name = "label252";
            this.label252.Size = new System.Drawing.Size(20, 20);
            this.label252.TabIndex = 252;
            // 
            // label253
            // 
            this.label253.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label253.Location = new System.Drawing.Point(240, 240);
            this.label253.Name = "label253";
            this.label253.Size = new System.Drawing.Size(20, 20);
            this.label253.TabIndex = 253;
            // 
            // label254
            // 
            this.label254.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label254.Location = new System.Drawing.Point(260, 240);
            this.label254.Name = "label254";
            this.label254.Size = new System.Drawing.Size(20, 20);
            this.label254.TabIndex = 254;
            // 
            // label255
            // 
            this.label255.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label255.Location = new System.Drawing.Point(280, 240);
            this.label255.Name = "label255";
            this.label255.Size = new System.Drawing.Size(20, 20);
            this.label255.TabIndex = 255;
            // 
            // label256
            // 
            this.label256.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label256.Location = new System.Drawing.Point(300, 240);
            this.label256.Name = "label256";
            this.label256.Size = new System.Drawing.Size(20, 20);
            this.label256.TabIndex = 256;
            // 
            // label257
            // 
            this.label257.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label257.Location = new System.Drawing.Point(320, 240);
            this.label257.Name = "label257";
            this.label257.Size = new System.Drawing.Size(20, 20);
            this.label257.TabIndex = 257;
            // 
            // label258
            // 
            this.label258.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label258.Location = new System.Drawing.Point(340, 240);
            this.label258.Name = "label258";
            this.label258.Size = new System.Drawing.Size(20, 20);
            this.label258.TabIndex = 258;
            // 
            // label259
            // 
            this.label259.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label259.Location = new System.Drawing.Point(360, 240);
            this.label259.Name = "label259";
            this.label259.Size = new System.Drawing.Size(20, 20);
            this.label259.TabIndex = 259;
            // 
            // label260
            // 
            this.label260.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label260.Location = new System.Drawing.Point(380, 240);
            this.label260.Name = "label260";
            this.label260.Size = new System.Drawing.Size(20, 20);
            this.label260.TabIndex = 260;
            // 
            // label261
            // 
            this.label261.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label261.Location = new System.Drawing.Point(0, 260);
            this.label261.Name = "label261";
            this.label261.Size = new System.Drawing.Size(20, 20);
            this.label261.TabIndex = 261;
            // 
            // label262
            // 
            this.label262.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label262.Location = new System.Drawing.Point(20, 260);
            this.label262.Name = "label262";
            this.label262.Size = new System.Drawing.Size(20, 20);
            this.label262.TabIndex = 262;
            // 
            // label263
            // 
            this.label263.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label263.Location = new System.Drawing.Point(40, 260);
            this.label263.Name = "label263";
            this.label263.Size = new System.Drawing.Size(20, 20);
            this.label263.TabIndex = 263;
            // 
            // label264
            // 
            this.label264.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label264.Location = new System.Drawing.Point(60, 260);
            this.label264.Name = "label264";
            this.label264.Size = new System.Drawing.Size(20, 20);
            this.label264.TabIndex = 264;
            // 
            // label265
            // 
            this.label265.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label265.Location = new System.Drawing.Point(80, 260);
            this.label265.Name = "label265";
            this.label265.Size = new System.Drawing.Size(20, 20);
            this.label265.TabIndex = 265;
            // 
            // label266
            // 
            this.label266.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label266.Location = new System.Drawing.Point(100, 260);
            this.label266.Name = "label266";
            this.label266.Size = new System.Drawing.Size(20, 20);
            this.label266.TabIndex = 266;
            // 
            // label267
            // 
            this.label267.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label267.Location = new System.Drawing.Point(120, 260);
            this.label267.Name = "label267";
            this.label267.Size = new System.Drawing.Size(20, 20);
            this.label267.TabIndex = 267;
            // 
            // label268
            // 
            this.label268.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label268.Location = new System.Drawing.Point(140, 260);
            this.label268.Name = "label268";
            this.label268.Size = new System.Drawing.Size(20, 20);
            this.label268.TabIndex = 268;
            // 
            // label269
            // 
            this.label269.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label269.Location = new System.Drawing.Point(160, 260);
            this.label269.Name = "label269";
            this.label269.Size = new System.Drawing.Size(20, 20);
            this.label269.TabIndex = 269;
            // 
            // label270
            // 
            this.label270.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label270.Location = new System.Drawing.Point(180, 260);
            this.label270.Name = "label270";
            this.label270.Size = new System.Drawing.Size(20, 20);
            this.label270.TabIndex = 270;
            // 
            // label271
            // 
            this.label271.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label271.Location = new System.Drawing.Point(200, 260);
            this.label271.Name = "label271";
            this.label271.Size = new System.Drawing.Size(20, 20);
            this.label271.TabIndex = 271;
            // 
            // label272
            // 
            this.label272.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label272.Location = new System.Drawing.Point(220, 260);
            this.label272.Name = "label272";
            this.label272.Size = new System.Drawing.Size(20, 20);
            this.label272.TabIndex = 272;
            // 
            // label273
            // 
            this.label273.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label273.Location = new System.Drawing.Point(240, 260);
            this.label273.Name = "label273";
            this.label273.Size = new System.Drawing.Size(20, 20);
            this.label273.TabIndex = 273;
            // 
            // label274
            // 
            this.label274.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label274.Location = new System.Drawing.Point(260, 260);
            this.label274.Name = "label274";
            this.label274.Size = new System.Drawing.Size(20, 20);
            this.label274.TabIndex = 274;
            // 
            // label275
            // 
            this.label275.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label275.Location = new System.Drawing.Point(280, 260);
            this.label275.Name = "label275";
            this.label275.Size = new System.Drawing.Size(20, 20);
            this.label275.TabIndex = 275;
            // 
            // label276
            // 
            this.label276.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label276.Location = new System.Drawing.Point(300, 260);
            this.label276.Name = "label276";
            this.label276.Size = new System.Drawing.Size(20, 20);
            this.label276.TabIndex = 276;
            // 
            // label277
            // 
            this.label277.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label277.Location = new System.Drawing.Point(320, 260);
            this.label277.Name = "label277";
            this.label277.Size = new System.Drawing.Size(20, 20);
            this.label277.TabIndex = 277;
            // 
            // label278
            // 
            this.label278.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label278.Location = new System.Drawing.Point(340, 260);
            this.label278.Name = "label278";
            this.label278.Size = new System.Drawing.Size(20, 20);
            this.label278.TabIndex = 278;
            // 
            // label279
            // 
            this.label279.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label279.Location = new System.Drawing.Point(360, 260);
            this.label279.Name = "label279";
            this.label279.Size = new System.Drawing.Size(20, 20);
            this.label279.TabIndex = 279;
            // 
            // label280
            // 
            this.label280.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label280.Location = new System.Drawing.Point(380, 260);
            this.label280.Name = "label280";
            this.label280.Size = new System.Drawing.Size(20, 20);
            this.label280.TabIndex = 280;
            // 
            // label281
            // 
            this.label281.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label281.Location = new System.Drawing.Point(0, 280);
            this.label281.Name = "label281";
            this.label281.Size = new System.Drawing.Size(20, 20);
            this.label281.TabIndex = 281;
            // 
            // label282
            // 
            this.label282.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label282.Location = new System.Drawing.Point(20, 280);
            this.label282.Name = "label282";
            this.label282.Size = new System.Drawing.Size(20, 20);
            this.label282.TabIndex = 282;
            // 
            // label283
            // 
            this.label283.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label283.Location = new System.Drawing.Point(40, 280);
            this.label283.Name = "label283";
            this.label283.Size = new System.Drawing.Size(20, 20);
            this.label283.TabIndex = 283;
            // 
            // label284
            // 
            this.label284.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label284.Location = new System.Drawing.Point(60, 280);
            this.label284.Name = "label284";
            this.label284.Size = new System.Drawing.Size(20, 20);
            this.label284.TabIndex = 284;
            // 
            // label285
            // 
            this.label285.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label285.Location = new System.Drawing.Point(80, 280);
            this.label285.Name = "label285";
            this.label285.Size = new System.Drawing.Size(20, 20);
            this.label285.TabIndex = 285;
            // 
            // label286
            // 
            this.label286.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label286.Location = new System.Drawing.Point(100, 280);
            this.label286.Name = "label286";
            this.label286.Size = new System.Drawing.Size(20, 20);
            this.label286.TabIndex = 286;
            // 
            // label287
            // 
            this.label287.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label287.Location = new System.Drawing.Point(120, 280);
            this.label287.Name = "label287";
            this.label287.Size = new System.Drawing.Size(20, 20);
            this.label287.TabIndex = 287;
            // 
            // label288
            // 
            this.label288.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label288.Location = new System.Drawing.Point(140, 280);
            this.label288.Name = "label288";
            this.label288.Size = new System.Drawing.Size(20, 20);
            this.label288.TabIndex = 288;
            // 
            // label289
            // 
            this.label289.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label289.Location = new System.Drawing.Point(160, 280);
            this.label289.Name = "label289";
            this.label289.Size = new System.Drawing.Size(20, 20);
            this.label289.TabIndex = 289;
            // 
            // label290
            // 
            this.label290.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label290.Location = new System.Drawing.Point(180, 280);
            this.label290.Name = "label290";
            this.label290.Size = new System.Drawing.Size(20, 20);
            this.label290.TabIndex = 290;
            // 
            // label291
            // 
            this.label291.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label291.Location = new System.Drawing.Point(200, 280);
            this.label291.Name = "label291";
            this.label291.Size = new System.Drawing.Size(20, 20);
            this.label291.TabIndex = 291;
            // 
            // label292
            // 
            this.label292.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label292.Location = new System.Drawing.Point(220, 280);
            this.label292.Name = "label292";
            this.label292.Size = new System.Drawing.Size(20, 20);
            this.label292.TabIndex = 292;
            // 
            // label293
            // 
            this.label293.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label293.Location = new System.Drawing.Point(240, 280);
            this.label293.Name = "label293";
            this.label293.Size = new System.Drawing.Size(20, 20);
            this.label293.TabIndex = 293;
            // 
            // label294
            // 
            this.label294.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label294.Location = new System.Drawing.Point(260, 280);
            this.label294.Name = "label294";
            this.label294.Size = new System.Drawing.Size(20, 20);
            this.label294.TabIndex = 294;
            // 
            // label295
            // 
            this.label295.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label295.Location = new System.Drawing.Point(280, 280);
            this.label295.Name = "label295";
            this.label295.Size = new System.Drawing.Size(20, 20);
            this.label295.TabIndex = 295;
            // 
            // label296
            // 
            this.label296.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label296.Location = new System.Drawing.Point(300, 280);
            this.label296.Name = "label296";
            this.label296.Size = new System.Drawing.Size(20, 20);
            this.label296.TabIndex = 296;
            // 
            // label297
            // 
            this.label297.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label297.Location = new System.Drawing.Point(320, 280);
            this.label297.Name = "label297";
            this.label297.Size = new System.Drawing.Size(20, 20);
            this.label297.TabIndex = 297;
            // 
            // label298
            // 
            this.label298.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label298.Location = new System.Drawing.Point(340, 280);
            this.label298.Name = "label298";
            this.label298.Size = new System.Drawing.Size(20, 20);
            this.label298.TabIndex = 298;
            // 
            // label299
            // 
            this.label299.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label299.Location = new System.Drawing.Point(360, 280);
            this.label299.Name = "label299";
            this.label299.Size = new System.Drawing.Size(20, 20);
            this.label299.TabIndex = 299;
            // 
            // label300
            // 
            this.label300.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label300.Location = new System.Drawing.Point(380, 280);
            this.label300.Name = "label300";
            this.label300.Size = new System.Drawing.Size(20, 20);
            this.label300.TabIndex = 300;
            // 
            // label301
            // 
            this.label301.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label301.Location = new System.Drawing.Point(0, 300);
            this.label301.Name = "label301";
            this.label301.Size = new System.Drawing.Size(20, 20);
            this.label301.TabIndex = 301;
            // 
            // label302
            // 
            this.label302.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label302.Location = new System.Drawing.Point(20, 300);
            this.label302.Name = "label302";
            this.label302.Size = new System.Drawing.Size(20, 20);
            this.label302.TabIndex = 302;
            // 
            // label303
            // 
            this.label303.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label303.Location = new System.Drawing.Point(40, 300);
            this.label303.Name = "label303";
            this.label303.Size = new System.Drawing.Size(20, 20);
            this.label303.TabIndex = 303;
            // 
            // label304
            // 
            this.label304.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label304.Location = new System.Drawing.Point(60, 300);
            this.label304.Name = "label304";
            this.label304.Size = new System.Drawing.Size(20, 20);
            this.label304.TabIndex = 304;
            // 
            // label305
            // 
            this.label305.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label305.Location = new System.Drawing.Point(80, 300);
            this.label305.Name = "label305";
            this.label305.Size = new System.Drawing.Size(20, 20);
            this.label305.TabIndex = 305;
            // 
            // label306
            // 
            this.label306.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label306.Location = new System.Drawing.Point(100, 300);
            this.label306.Name = "label306";
            this.label306.Size = new System.Drawing.Size(20, 20);
            this.label306.TabIndex = 306;
            // 
            // label307
            // 
            this.label307.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label307.Location = new System.Drawing.Point(120, 300);
            this.label307.Name = "label307";
            this.label307.Size = new System.Drawing.Size(20, 20);
            this.label307.TabIndex = 307;
            // 
            // label308
            // 
            this.label308.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label308.Location = new System.Drawing.Point(140, 300);
            this.label308.Name = "label308";
            this.label308.Size = new System.Drawing.Size(20, 20);
            this.label308.TabIndex = 308;
            // 
            // label309
            // 
            this.label309.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label309.Location = new System.Drawing.Point(160, 300);
            this.label309.Name = "label309";
            this.label309.Size = new System.Drawing.Size(20, 20);
            this.label309.TabIndex = 309;
            // 
            // label310
            // 
            this.label310.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label310.Location = new System.Drawing.Point(180, 300);
            this.label310.Name = "label310";
            this.label310.Size = new System.Drawing.Size(20, 20);
            this.label310.TabIndex = 310;
            // 
            // label311
            // 
            this.label311.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label311.Location = new System.Drawing.Point(200, 300);
            this.label311.Name = "label311";
            this.label311.Size = new System.Drawing.Size(20, 20);
            this.label311.TabIndex = 311;
            // 
            // label312
            // 
            this.label312.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label312.Location = new System.Drawing.Point(220, 300);
            this.label312.Name = "label312";
            this.label312.Size = new System.Drawing.Size(20, 20);
            this.label312.TabIndex = 312;
            // 
            // label313
            // 
            this.label313.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label313.Location = new System.Drawing.Point(240, 300);
            this.label313.Name = "label313";
            this.label313.Size = new System.Drawing.Size(20, 20);
            this.label313.TabIndex = 313;
            // 
            // label314
            // 
            this.label314.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label314.Location = new System.Drawing.Point(260, 300);
            this.label314.Name = "label314";
            this.label314.Size = new System.Drawing.Size(20, 20);
            this.label314.TabIndex = 314;
            // 
            // label315
            // 
            this.label315.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label315.Location = new System.Drawing.Point(280, 300);
            this.label315.Name = "label315";
            this.label315.Size = new System.Drawing.Size(20, 20);
            this.label315.TabIndex = 315;
            // 
            // label316
            // 
            this.label316.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label316.Location = new System.Drawing.Point(300, 300);
            this.label316.Name = "label316";
            this.label316.Size = new System.Drawing.Size(20, 20);
            this.label316.TabIndex = 316;
            // 
            // label317
            // 
            this.label317.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label317.Location = new System.Drawing.Point(320, 300);
            this.label317.Name = "label317";
            this.label317.Size = new System.Drawing.Size(20, 20);
            this.label317.TabIndex = 317;
            // 
            // label318
            // 
            this.label318.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label318.Location = new System.Drawing.Point(340, 300);
            this.label318.Name = "label318";
            this.label318.Size = new System.Drawing.Size(20, 20);
            this.label318.TabIndex = 318;
            // 
            // label319
            // 
            this.label319.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label319.Location = new System.Drawing.Point(360, 300);
            this.label319.Name = "label319";
            this.label319.Size = new System.Drawing.Size(20, 20);
            this.label319.TabIndex = 319;
            // 
            // label320
            // 
            this.label320.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label320.Location = new System.Drawing.Point(380, 300);
            this.label320.Name = "label320";
            this.label320.Size = new System.Drawing.Size(20, 20);
            this.label320.TabIndex = 320;
            // 
            // label321
            // 
            this.label321.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label321.Location = new System.Drawing.Point(0, 320);
            this.label321.Name = "label321";
            this.label321.Size = new System.Drawing.Size(20, 20);
            this.label321.TabIndex = 321;
            // 
            // label322
            // 
            this.label322.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label322.Location = new System.Drawing.Point(20, 320);
            this.label322.Name = "label322";
            this.label322.Size = new System.Drawing.Size(20, 20);
            this.label322.TabIndex = 322;
            // 
            // label323
            // 
            this.label323.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label323.Location = new System.Drawing.Point(40, 320);
            this.label323.Name = "label323";
            this.label323.Size = new System.Drawing.Size(20, 20);
            this.label323.TabIndex = 323;
            // 
            // label324
            // 
            this.label324.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label324.Location = new System.Drawing.Point(60, 320);
            this.label324.Name = "label324";
            this.label324.Size = new System.Drawing.Size(20, 20);
            this.label324.TabIndex = 324;
            // 
            // label325
            // 
            this.label325.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label325.Location = new System.Drawing.Point(80, 320);
            this.label325.Name = "label325";
            this.label325.Size = new System.Drawing.Size(20, 20);
            this.label325.TabIndex = 325;
            // 
            // label326
            // 
            this.label326.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label326.Location = new System.Drawing.Point(100, 320);
            this.label326.Name = "label326";
            this.label326.Size = new System.Drawing.Size(20, 20);
            this.label326.TabIndex = 326;
            // 
            // label327
            // 
            this.label327.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label327.Location = new System.Drawing.Point(120, 320);
            this.label327.Name = "label327";
            this.label327.Size = new System.Drawing.Size(20, 20);
            this.label327.TabIndex = 327;
            // 
            // label328
            // 
            this.label328.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label328.Location = new System.Drawing.Point(140, 320);
            this.label328.Name = "label328";
            this.label328.Size = new System.Drawing.Size(20, 20);
            this.label328.TabIndex = 328;
            // 
            // label329
            // 
            this.label329.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label329.Location = new System.Drawing.Point(160, 320);
            this.label329.Name = "label329";
            this.label329.Size = new System.Drawing.Size(20, 20);
            this.label329.TabIndex = 329;
            // 
            // label330
            // 
            this.label330.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label330.Location = new System.Drawing.Point(180, 320);
            this.label330.Name = "label330";
            this.label330.Size = new System.Drawing.Size(20, 20);
            this.label330.TabIndex = 330;
            // 
            // label331
            // 
            this.label331.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label331.Location = new System.Drawing.Point(200, 320);
            this.label331.Name = "label331";
            this.label331.Size = new System.Drawing.Size(20, 20);
            this.label331.TabIndex = 331;
            // 
            // label332
            // 
            this.label332.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label332.Location = new System.Drawing.Point(220, 320);
            this.label332.Name = "label332";
            this.label332.Size = new System.Drawing.Size(20, 20);
            this.label332.TabIndex = 332;
            // 
            // label333
            // 
            this.label333.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label333.Location = new System.Drawing.Point(240, 320);
            this.label333.Name = "label333";
            this.label333.Size = new System.Drawing.Size(20, 20);
            this.label333.TabIndex = 333;
            // 
            // label334
            // 
            this.label334.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label334.Location = new System.Drawing.Point(260, 320);
            this.label334.Name = "label334";
            this.label334.Size = new System.Drawing.Size(20, 20);
            this.label334.TabIndex = 334;
            // 
            // label335
            // 
            this.label335.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label335.Location = new System.Drawing.Point(280, 320);
            this.label335.Name = "label335";
            this.label335.Size = new System.Drawing.Size(20, 20);
            this.label335.TabIndex = 335;
            // 
            // label336
            // 
            this.label336.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label336.Location = new System.Drawing.Point(300, 320);
            this.label336.Name = "label336";
            this.label336.Size = new System.Drawing.Size(20, 20);
            this.label336.TabIndex = 336;
            // 
            // label337
            // 
            this.label337.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label337.Location = new System.Drawing.Point(320, 320);
            this.label337.Name = "label337";
            this.label337.Size = new System.Drawing.Size(20, 20);
            this.label337.TabIndex = 337;
            // 
            // label338
            // 
            this.label338.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label338.Location = new System.Drawing.Point(340, 320);
            this.label338.Name = "label338";
            this.label338.Size = new System.Drawing.Size(20, 20);
            this.label338.TabIndex = 338;
            // 
            // label339
            // 
            this.label339.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label339.Location = new System.Drawing.Point(360, 320);
            this.label339.Name = "label339";
            this.label339.Size = new System.Drawing.Size(20, 20);
            this.label339.TabIndex = 339;
            // 
            // label340
            // 
            this.label340.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label340.Location = new System.Drawing.Point(380, 320);
            this.label340.Name = "label340";
            this.label340.Size = new System.Drawing.Size(20, 20);
            this.label340.TabIndex = 340;
            // 
            // label341
            // 
            this.label341.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label341.Location = new System.Drawing.Point(0, 340);
            this.label341.Name = "label341";
            this.label341.Size = new System.Drawing.Size(20, 20);
            this.label341.TabIndex = 341;
            // 
            // label342
            // 
            this.label342.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label342.Location = new System.Drawing.Point(20, 340);
            this.label342.Name = "label342";
            this.label342.Size = new System.Drawing.Size(20, 20);
            this.label342.TabIndex = 342;
            // 
            // label343
            // 
            this.label343.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label343.Location = new System.Drawing.Point(40, 340);
            this.label343.Name = "label343";
            this.label343.Size = new System.Drawing.Size(20, 20);
            this.label343.TabIndex = 343;
            // 
            // label344
            // 
            this.label344.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label344.Location = new System.Drawing.Point(60, 340);
            this.label344.Name = "label344";
            this.label344.Size = new System.Drawing.Size(20, 20);
            this.label344.TabIndex = 344;
            // 
            // label345
            // 
            this.label345.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label345.Location = new System.Drawing.Point(80, 340);
            this.label345.Name = "label345";
            this.label345.Size = new System.Drawing.Size(20, 20);
            this.label345.TabIndex = 345;
            // 
            // label346
            // 
            this.label346.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label346.Location = new System.Drawing.Point(100, 340);
            this.label346.Name = "label346";
            this.label346.Size = new System.Drawing.Size(20, 20);
            this.label346.TabIndex = 346;
            // 
            // label347
            // 
            this.label347.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label347.Location = new System.Drawing.Point(120, 340);
            this.label347.Name = "label347";
            this.label347.Size = new System.Drawing.Size(20, 20);
            this.label347.TabIndex = 347;
            // 
            // label348
            // 
            this.label348.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label348.Location = new System.Drawing.Point(140, 340);
            this.label348.Name = "label348";
            this.label348.Size = new System.Drawing.Size(20, 20);
            this.label348.TabIndex = 348;
            // 
            // label349
            // 
            this.label349.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label349.Location = new System.Drawing.Point(160, 340);
            this.label349.Name = "label349";
            this.label349.Size = new System.Drawing.Size(20, 20);
            this.label349.TabIndex = 349;
            // 
            // label350
            // 
            this.label350.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label350.Location = new System.Drawing.Point(180, 340);
            this.label350.Name = "label350";
            this.label350.Size = new System.Drawing.Size(20, 20);
            this.label350.TabIndex = 350;
            // 
            // label351
            // 
            this.label351.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label351.Location = new System.Drawing.Point(200, 340);
            this.label351.Name = "label351";
            this.label351.Size = new System.Drawing.Size(20, 20);
            this.label351.TabIndex = 351;
            // 
            // label352
            // 
            this.label352.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label352.Location = new System.Drawing.Point(220, 340);
            this.label352.Name = "label352";
            this.label352.Size = new System.Drawing.Size(20, 20);
            this.label352.TabIndex = 352;
            // 
            // label353
            // 
            this.label353.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label353.Location = new System.Drawing.Point(240, 340);
            this.label353.Name = "label353";
            this.label353.Size = new System.Drawing.Size(20, 20);
            this.label353.TabIndex = 353;
            // 
            // label354
            // 
            this.label354.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label354.Location = new System.Drawing.Point(260, 340);
            this.label354.Name = "label354";
            this.label354.Size = new System.Drawing.Size(20, 20);
            this.label354.TabIndex = 354;
            // 
            // label355
            // 
            this.label355.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label355.Location = new System.Drawing.Point(280, 340);
            this.label355.Name = "label355";
            this.label355.Size = new System.Drawing.Size(20, 20);
            this.label355.TabIndex = 355;
            // 
            // label356
            // 
            this.label356.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label356.Location = new System.Drawing.Point(300, 340);
            this.label356.Name = "label356";
            this.label356.Size = new System.Drawing.Size(20, 20);
            this.label356.TabIndex = 356;
            // 
            // label357
            // 
            this.label357.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label357.Location = new System.Drawing.Point(320, 340);
            this.label357.Name = "label357";
            this.label357.Size = new System.Drawing.Size(20, 20);
            this.label357.TabIndex = 357;
            // 
            // label358
            // 
            this.label358.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label358.Location = new System.Drawing.Point(340, 340);
            this.label358.Name = "label358";
            this.label358.Size = new System.Drawing.Size(20, 20);
            this.label358.TabIndex = 358;
            // 
            // label359
            // 
            this.label359.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label359.Location = new System.Drawing.Point(360, 340);
            this.label359.Name = "label359";
            this.label359.Size = new System.Drawing.Size(20, 20);
            this.label359.TabIndex = 359;
            // 
            // label360
            // 
            this.label360.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label360.Location = new System.Drawing.Point(380, 340);
            this.label360.Name = "label360";
            this.label360.Size = new System.Drawing.Size(20, 20);
            this.label360.TabIndex = 360;
            // 
            // label361
            // 
            this.label361.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label361.Location = new System.Drawing.Point(0, 360);
            this.label361.Name = "label361";
            this.label361.Size = new System.Drawing.Size(20, 20);
            this.label361.TabIndex = 361;
            // 
            // label362
            // 
            this.label362.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label362.Location = new System.Drawing.Point(20, 360);
            this.label362.Name = "label362";
            this.label362.Size = new System.Drawing.Size(20, 20);
            this.label362.TabIndex = 362;
            // 
            // label363
            // 
            this.label363.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label363.Location = new System.Drawing.Point(40, 360);
            this.label363.Name = "label363";
            this.label363.Size = new System.Drawing.Size(20, 20);
            this.label363.TabIndex = 363;
            // 
            // label364
            // 
            this.label364.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label364.Location = new System.Drawing.Point(60, 360);
            this.label364.Name = "label364";
            this.label364.Size = new System.Drawing.Size(20, 20);
            this.label364.TabIndex = 364;
            // 
            // label365
            // 
            this.label365.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label365.Location = new System.Drawing.Point(80, 360);
            this.label365.Name = "label365";
            this.label365.Size = new System.Drawing.Size(20, 20);
            this.label365.TabIndex = 365;
            // 
            // label366
            // 
            this.label366.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label366.Location = new System.Drawing.Point(100, 360);
            this.label366.Name = "label366";
            this.label366.Size = new System.Drawing.Size(20, 20);
            this.label366.TabIndex = 366;
            // 
            // label367
            // 
            this.label367.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label367.Location = new System.Drawing.Point(120, 360);
            this.label367.Name = "label367";
            this.label367.Size = new System.Drawing.Size(20, 20);
            this.label367.TabIndex = 367;
            // 
            // label368
            // 
            this.label368.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label368.Location = new System.Drawing.Point(140, 360);
            this.label368.Name = "label368";
            this.label368.Size = new System.Drawing.Size(20, 20);
            this.label368.TabIndex = 368;
            // 
            // label369
            // 
            this.label369.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label369.Location = new System.Drawing.Point(160, 360);
            this.label369.Name = "label369";
            this.label369.Size = new System.Drawing.Size(20, 20);
            this.label369.TabIndex = 369;
            // 
            // label370
            // 
            this.label370.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label370.Location = new System.Drawing.Point(180, 360);
            this.label370.Name = "label370";
            this.label370.Size = new System.Drawing.Size(20, 20);
            this.label370.TabIndex = 370;
            // 
            // label371
            // 
            this.label371.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label371.Location = new System.Drawing.Point(200, 360);
            this.label371.Name = "label371";
            this.label371.Size = new System.Drawing.Size(20, 20);
            this.label371.TabIndex = 371;
            // 
            // label372
            // 
            this.label372.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label372.Location = new System.Drawing.Point(220, 360);
            this.label372.Name = "label372";
            this.label372.Size = new System.Drawing.Size(20, 20);
            this.label372.TabIndex = 372;
            // 
            // label373
            // 
            this.label373.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label373.Location = new System.Drawing.Point(240, 360);
            this.label373.Name = "label373";
            this.label373.Size = new System.Drawing.Size(20, 20);
            this.label373.TabIndex = 373;
            // 
            // label374
            // 
            this.label374.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label374.Location = new System.Drawing.Point(260, 360);
            this.label374.Name = "label374";
            this.label374.Size = new System.Drawing.Size(20, 20);
            this.label374.TabIndex = 374;
            // 
            // label375
            // 
            this.label375.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label375.Location = new System.Drawing.Point(280, 360);
            this.label375.Name = "label375";
            this.label375.Size = new System.Drawing.Size(20, 20);
            this.label375.TabIndex = 375;
            // 
            // label376
            // 
            this.label376.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label376.Location = new System.Drawing.Point(300, 360);
            this.label376.Name = "label376";
            this.label376.Size = new System.Drawing.Size(20, 20);
            this.label376.TabIndex = 376;
            // 
            // label377
            // 
            this.label377.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label377.Location = new System.Drawing.Point(320, 360);
            this.label377.Name = "label377";
            this.label377.Size = new System.Drawing.Size(20, 20);
            this.label377.TabIndex = 377;
            // 
            // label378
            // 
            this.label378.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label378.Location = new System.Drawing.Point(340, 360);
            this.label378.Name = "label378";
            this.label378.Size = new System.Drawing.Size(20, 20);
            this.label378.TabIndex = 378;
            // 
            // label379
            // 
            this.label379.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label379.Location = new System.Drawing.Point(360, 360);
            this.label379.Name = "label379";
            this.label379.Size = new System.Drawing.Size(20, 20);
            this.label379.TabIndex = 379;
            // 
            // label380
            // 
            this.label380.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label380.Location = new System.Drawing.Point(380, 360);
            this.label380.Name = "label380";
            this.label380.Size = new System.Drawing.Size(20, 20);
            this.label380.TabIndex = 380;
            // 
            // label381
            // 
            this.label381.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label381.Location = new System.Drawing.Point(0, 380);
            this.label381.Name = "label381";
            this.label381.Size = new System.Drawing.Size(20, 20);
            this.label381.TabIndex = 381;
            // 
            // label382
            // 
            this.label382.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label382.Location = new System.Drawing.Point(20, 380);
            this.label382.Name = "label382";
            this.label382.Size = new System.Drawing.Size(20, 20);
            this.label382.TabIndex = 382;
            // 
            // label383
            // 
            this.label383.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label383.Location = new System.Drawing.Point(40, 380);
            this.label383.Name = "label383";
            this.label383.Size = new System.Drawing.Size(20, 20);
            this.label383.TabIndex = 383;
            // 
            // label384
            // 
            this.label384.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label384.Location = new System.Drawing.Point(60, 380);
            this.label384.Name = "label384";
            this.label384.Size = new System.Drawing.Size(20, 20);
            this.label384.TabIndex = 384;
            // 
            // label385
            // 
            this.label385.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label385.Location = new System.Drawing.Point(80, 380);
            this.label385.Name = "label385";
            this.label385.Size = new System.Drawing.Size(20, 20);
            this.label385.TabIndex = 385;
            // 
            // label386
            // 
            this.label386.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label386.Location = new System.Drawing.Point(100, 380);
            this.label386.Name = "label386";
            this.label386.Size = new System.Drawing.Size(20, 20);
            this.label386.TabIndex = 386;
            // 
            // label387
            // 
            this.label387.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label387.Location = new System.Drawing.Point(120, 380);
            this.label387.Name = "label387";
            this.label387.Size = new System.Drawing.Size(20, 20);
            this.label387.TabIndex = 387;
            // 
            // label388
            // 
            this.label388.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label388.Location = new System.Drawing.Point(140, 380);
            this.label388.Name = "label388";
            this.label388.Size = new System.Drawing.Size(20, 20);
            this.label388.TabIndex = 388;
            // 
            // label389
            // 
            this.label389.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label389.Location = new System.Drawing.Point(160, 380);
            this.label389.Name = "label389";
            this.label389.Size = new System.Drawing.Size(20, 20);
            this.label389.TabIndex = 389;
            // 
            // label390
            // 
            this.label390.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label390.Location = new System.Drawing.Point(180, 380);
            this.label390.Name = "label390";
            this.label390.Size = new System.Drawing.Size(20, 20);
            this.label390.TabIndex = 390;
            // 
            // label391
            // 
            this.label391.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label391.Location = new System.Drawing.Point(200, 380);
            this.label391.Name = "label391";
            this.label391.Size = new System.Drawing.Size(20, 20);
            this.label391.TabIndex = 391;
            // 
            // label392
            // 
            this.label392.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label392.Location = new System.Drawing.Point(220, 380);
            this.label392.Name = "label392";
            this.label392.Size = new System.Drawing.Size(20, 20);
            this.label392.TabIndex = 392;
            // 
            // label393
            // 
            this.label393.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label393.Location = new System.Drawing.Point(240, 380);
            this.label393.Name = "label393";
            this.label393.Size = new System.Drawing.Size(20, 20);
            this.label393.TabIndex = 393;
            // 
            // label394
            // 
            this.label394.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label394.Location = new System.Drawing.Point(260, 380);
            this.label394.Name = "label394";
            this.label394.Size = new System.Drawing.Size(20, 20);
            this.label394.TabIndex = 394;
            // 
            // label395
            // 
            this.label395.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label395.Location = new System.Drawing.Point(280, 380);
            this.label395.Name = "label395";
            this.label395.Size = new System.Drawing.Size(20, 20);
            this.label395.TabIndex = 395;
            // 
            // label396
            // 
            this.label396.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label396.Location = new System.Drawing.Point(300, 380);
            this.label396.Name = "label396";
            this.label396.Size = new System.Drawing.Size(20, 20);
            this.label396.TabIndex = 396;
            // 
            // label397
            // 
            this.label397.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label397.Location = new System.Drawing.Point(320, 380);
            this.label397.Name = "label397";
            this.label397.Size = new System.Drawing.Size(20, 20);
            this.label397.TabIndex = 397;
            // 
            // label398
            // 
            this.label398.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label398.Location = new System.Drawing.Point(340, 380);
            this.label398.Name = "label398";
            this.label398.Size = new System.Drawing.Size(20, 20);
            this.label398.TabIndex = 398;
            // 
            // label399
            // 
            this.label399.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label399.Location = new System.Drawing.Point(360, 380);
            this.label399.Name = "label399";
            this.label399.Size = new System.Drawing.Size(20, 20);
            this.label399.TabIndex = 399;
            // 
            // label400
            // 
            this.label400.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label400.Location = new System.Drawing.Point(380, 380);
            this.label400.Name = "label400";
            this.label400.Size = new System.Drawing.Size(20, 20);
            this.label400.TabIndex = 400;
            // 
            // btnup
            // 
            this.btnup.Font = new System.Drawing.Font("Wingdings 3", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(2)));
            this.btnup.Location = new System.Drawing.Point(276, 445);
            this.btnup.Name = "btnup";
            this.btnup.Size = new System.Drawing.Size(75, 23);
            this.btnup.TabIndex = 1;
            this.btnup.Text = "h";
            this.btnup.UseVisualStyleBackColor = true;
            this.btnup.Click += new System.EventHandler(this.btnup_Click);
            // 
            // btnleft
            // 
            this.btnleft.Font = new System.Drawing.Font("Wingdings 3", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(2)));
            this.btnleft.Location = new System.Drawing.Point(214, 474);
            this.btnleft.Name = "btnleft";
            this.btnleft.Size = new System.Drawing.Size(75, 23);
            this.btnleft.TabIndex = 2;
            this.btnleft.Text = "f";
            this.btnleft.UseVisualStyleBackColor = true;
            this.btnleft.Click += new System.EventHandler(this.btnleft_Click);
            // 
            // btnright
            // 
            this.btnright.Font = new System.Drawing.Font("Wingdings 3", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(2)));
            this.btnright.Location = new System.Drawing.Point(336, 474);
            this.btnright.Name = "btnright";
            this.btnright.Size = new System.Drawing.Size(75, 23);
            this.btnright.TabIndex = 3;
            this.btnright.Text = "g";
            this.btnright.UseVisualStyleBackColor = true;
            this.btnright.Click += new System.EventHandler(this.btnright_Click);
            // 
            // btndown
            // 
            this.btndown.Font = new System.Drawing.Font("Wingdings 3", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(2)));
            this.btndown.Location = new System.Drawing.Point(276, 503);
            this.btndown.Name = "btndown";
            this.btndown.Size = new System.Drawing.Size(75, 23);
            this.btndown.TabIndex = 4;
            this.btndown.Text = "i";
            this.btndown.UseVisualStyleBackColor = true;
            this.btndown.Click += new System.EventHandler(this.btndown_Click);
            // 
            // lbldanger
            // 
            this.lbldanger.AutoSize = true;
            this.lbldanger.Font = new System.Drawing.Font("Stencil", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbldanger.Location = new System.Drawing.Point(13, 437);
            this.lbldanger.Name = "lbldanger";
            this.lbldanger.Size = new System.Drawing.Size(103, 16);
            this.lbldanger.TabIndex = 5;
            this.lbldanger.Text = "Danger Level:";
            // 
            // lblstatus
            // 
            this.lblstatus.BackColor = System.Drawing.Color.Transparent;
            this.lblstatus.Location = new System.Drawing.Point(15, 460);
            this.lblstatus.Name = "lblstatus";
            this.lblstatus.Size = new System.Drawing.Size(193, 73);
            this.lblstatus.TabIndex = 401;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(429, 542);
            this.Controls.Add(this.lblstatus);
            this.Controls.Add(this.lbldanger);
            this.Controls.Add(this.btndown);
            this.Controls.Add(this.btnright);
            this.Controls.Add(this.btnleft);
            this.Controls.Add(this.btnup);
            this.Controls.Add(this.panel1);
            this.Name = "Form1";
            this.Text = "Minefirld";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.panel1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.Label label52;
        private System.Windows.Forms.Label label53;
        private System.Windows.Forms.Label label54;
        private System.Windows.Forms.Label label55;
        private System.Windows.Forms.Label label56;
        private System.Windows.Forms.Label label57;
        private System.Windows.Forms.Label label58;
        private System.Windows.Forms.Label label59;
        private System.Windows.Forms.Label label60;
        private System.Windows.Forms.Label label61;
        private System.Windows.Forms.Label label62;
        private System.Windows.Forms.Label label63;
        private System.Windows.Forms.Label label64;
        private System.Windows.Forms.Label label65;
        private System.Windows.Forms.Label label66;
        private System.Windows.Forms.Label label67;
        private System.Windows.Forms.Label label68;
        private System.Windows.Forms.Label label69;
        private System.Windows.Forms.Label label70;
        private System.Windows.Forms.Label label71;
        private System.Windows.Forms.Label label72;
        private System.Windows.Forms.Label label73;
        private System.Windows.Forms.Label label74;
        private System.Windows.Forms.Label label75;
        private System.Windows.Forms.Label label76;
        private System.Windows.Forms.Label label77;
        private System.Windows.Forms.Label label78;
        private System.Windows.Forms.Label label79;
        private System.Windows.Forms.Label label80;
        private System.Windows.Forms.Label label81;
        private System.Windows.Forms.Label label82;
        private System.Windows.Forms.Label label83;
        private System.Windows.Forms.Label label84;
        private System.Windows.Forms.Label label85;
        private System.Windows.Forms.Label label86;
        private System.Windows.Forms.Label label87;
        private System.Windows.Forms.Label label88;
        private System.Windows.Forms.Label label89;
        private System.Windows.Forms.Label label90;
        private System.Windows.Forms.Label label91;
        private System.Windows.Forms.Label label92;
        private System.Windows.Forms.Label label93;
        private System.Windows.Forms.Label label94;
        private System.Windows.Forms.Label label95;
        private System.Windows.Forms.Label label96;
        private System.Windows.Forms.Label label97;
        private System.Windows.Forms.Label label98;
        private System.Windows.Forms.Label label99;
        private System.Windows.Forms.Label label100;
        private System.Windows.Forms.Label label101;
        private System.Windows.Forms.Label label102;
        private System.Windows.Forms.Label label103;
        private System.Windows.Forms.Label label104;
        private System.Windows.Forms.Label label105;
        private System.Windows.Forms.Label label106;
        private System.Windows.Forms.Label label107;
        private System.Windows.Forms.Label label108;
        private System.Windows.Forms.Label label109;
        private System.Windows.Forms.Label label110;
        private System.Windows.Forms.Label label111;
        private System.Windows.Forms.Label label112;
        private System.Windows.Forms.Label label113;
        private System.Windows.Forms.Label label114;
        private System.Windows.Forms.Label label115;
        private System.Windows.Forms.Label label116;
        private System.Windows.Forms.Label label117;
        private System.Windows.Forms.Label label118;
        private System.Windows.Forms.Label label119;
        private System.Windows.Forms.Label label120;
        private System.Windows.Forms.Label label121;
        private System.Windows.Forms.Label label122;
        private System.Windows.Forms.Label label123;
        private System.Windows.Forms.Label label124;
        private System.Windows.Forms.Label label125;
        private System.Windows.Forms.Label label126;
        private System.Windows.Forms.Label label127;
        private System.Windows.Forms.Label label128;
        private System.Windows.Forms.Label label129;
        private System.Windows.Forms.Label label130;
        private System.Windows.Forms.Label label131;
        private System.Windows.Forms.Label label132;
        private System.Windows.Forms.Label label133;
        private System.Windows.Forms.Label label134;
        private System.Windows.Forms.Label label135;
        private System.Windows.Forms.Label label136;
        private System.Windows.Forms.Label label137;
        private System.Windows.Forms.Label label138;
        private System.Windows.Forms.Label label139;
        private System.Windows.Forms.Label label140;
        private System.Windows.Forms.Label label141;
        private System.Windows.Forms.Label label142;
        private System.Windows.Forms.Label label143;
        private System.Windows.Forms.Label label144;
        private System.Windows.Forms.Label label145;
        private System.Windows.Forms.Label label146;
        private System.Windows.Forms.Label label147;
        private System.Windows.Forms.Label label148;
        private System.Windows.Forms.Label label149;
        private System.Windows.Forms.Label label150;
        private System.Windows.Forms.Label label151;
        private System.Windows.Forms.Label label152;
        private System.Windows.Forms.Label label153;
        private System.Windows.Forms.Label label154;
        private System.Windows.Forms.Label label155;
        private System.Windows.Forms.Label label156;
        private System.Windows.Forms.Label label157;
        private System.Windows.Forms.Label label158;
        private System.Windows.Forms.Label label159;
        private System.Windows.Forms.Label label160;
        private System.Windows.Forms.Label label161;
        private System.Windows.Forms.Label label162;
        private System.Windows.Forms.Label label163;
        private System.Windows.Forms.Label label164;
        private System.Windows.Forms.Label label165;
        private System.Windows.Forms.Label label166;
        private System.Windows.Forms.Label label167;
        private System.Windows.Forms.Label label168;
        private System.Windows.Forms.Label label169;
        private System.Windows.Forms.Label label170;
        private System.Windows.Forms.Label label171;
        private System.Windows.Forms.Label label172;
        private System.Windows.Forms.Label label173;
        private System.Windows.Forms.Label label174;
        private System.Windows.Forms.Label label175;
        private System.Windows.Forms.Label label176;
        private System.Windows.Forms.Label label177;
        private System.Windows.Forms.Label label178;
        private System.Windows.Forms.Label label179;
        private System.Windows.Forms.Label label180;
        private System.Windows.Forms.Label label181;
        private System.Windows.Forms.Label label182;
        private System.Windows.Forms.Label label183;
        private System.Windows.Forms.Label label184;
        private System.Windows.Forms.Label label185;
        private System.Windows.Forms.Label label186;
        private System.Windows.Forms.Label label187;
        private System.Windows.Forms.Label label188;
        private System.Windows.Forms.Label label189;
        private System.Windows.Forms.Label label190;
        private System.Windows.Forms.Label label191;
        private System.Windows.Forms.Label label192;
        private System.Windows.Forms.Label label193;
        private System.Windows.Forms.Label label194;
        private System.Windows.Forms.Label label195;
        private System.Windows.Forms.Label label196;
        private System.Windows.Forms.Label label197;
        private System.Windows.Forms.Label label198;
        private System.Windows.Forms.Label label199;
        private System.Windows.Forms.Label label200;
        private System.Windows.Forms.Label label201;
        private System.Windows.Forms.Label label202;
        private System.Windows.Forms.Label label203;
        private System.Windows.Forms.Label label204;
        private System.Windows.Forms.Label label205;
        private System.Windows.Forms.Label label206;
        private System.Windows.Forms.Label label207;
        private System.Windows.Forms.Label label208;
        private System.Windows.Forms.Label label209;
        private System.Windows.Forms.Label label210;
        private System.Windows.Forms.Label label211;
        private System.Windows.Forms.Label label212;
        private System.Windows.Forms.Label label213;
        private System.Windows.Forms.Label label214;
        private System.Windows.Forms.Label label215;
        private System.Windows.Forms.Label label216;
        private System.Windows.Forms.Label label217;
        private System.Windows.Forms.Label label218;
        private System.Windows.Forms.Label label219;
        private System.Windows.Forms.Label label220;
        private System.Windows.Forms.Label label221;
        private System.Windows.Forms.Label label222;
        private System.Windows.Forms.Label label223;
        private System.Windows.Forms.Label label224;
        private System.Windows.Forms.Label label225;
        private System.Windows.Forms.Label label226;
        private System.Windows.Forms.Label label227;
        private System.Windows.Forms.Label label228;
        private System.Windows.Forms.Label label229;
        private System.Windows.Forms.Label label230;
        private System.Windows.Forms.Label label231;
        private System.Windows.Forms.Label label232;
        private System.Windows.Forms.Label label233;
        private System.Windows.Forms.Label label234;
        private System.Windows.Forms.Label label235;
        private System.Windows.Forms.Label label236;
        private System.Windows.Forms.Label label237;
        private System.Windows.Forms.Label label238;
        private System.Windows.Forms.Label label239;
        private System.Windows.Forms.Label label240;
        private System.Windows.Forms.Label label241;
        private System.Windows.Forms.Label label242;
        private System.Windows.Forms.Label label243;
        private System.Windows.Forms.Label label244;
        private System.Windows.Forms.Label label245;
        private System.Windows.Forms.Label label246;
        private System.Windows.Forms.Label label247;
        private System.Windows.Forms.Label label248;
        private System.Windows.Forms.Label label249;
        private System.Windows.Forms.Label label250;
        private System.Windows.Forms.Label label251;
        private System.Windows.Forms.Label label252;
        private System.Windows.Forms.Label label253;
        private System.Windows.Forms.Label label254;
        private System.Windows.Forms.Label label255;
        private System.Windows.Forms.Label label256;
        private System.Windows.Forms.Label label257;
        private System.Windows.Forms.Label label258;
        private System.Windows.Forms.Label label259;
        private System.Windows.Forms.Label label260;
        private System.Windows.Forms.Label label261;
        private System.Windows.Forms.Label label262;
        private System.Windows.Forms.Label label263;
        private System.Windows.Forms.Label label264;
        private System.Windows.Forms.Label label265;
        private System.Windows.Forms.Label label266;
        private System.Windows.Forms.Label label267;
        private System.Windows.Forms.Label label268;
        private System.Windows.Forms.Label label269;
        private System.Windows.Forms.Label label270;
        private System.Windows.Forms.Label label271;
        private System.Windows.Forms.Label label272;
        private System.Windows.Forms.Label label273;
        private System.Windows.Forms.Label label274;
        private System.Windows.Forms.Label label275;
        private System.Windows.Forms.Label label276;
        private System.Windows.Forms.Label label277;
        private System.Windows.Forms.Label label278;
        private System.Windows.Forms.Label label279;
        private System.Windows.Forms.Label label280;
        private System.Windows.Forms.Label label281;
        private System.Windows.Forms.Label label282;
        private System.Windows.Forms.Label label283;
        private System.Windows.Forms.Label label284;
        private System.Windows.Forms.Label label285;
        private System.Windows.Forms.Label label286;
        private System.Windows.Forms.Label label287;
        private System.Windows.Forms.Label label288;
        private System.Windows.Forms.Label label289;
        private System.Windows.Forms.Label label290;
        private System.Windows.Forms.Label label291;
        private System.Windows.Forms.Label label292;
        private System.Windows.Forms.Label label293;
        private System.Windows.Forms.Label label294;
        private System.Windows.Forms.Label label295;
        private System.Windows.Forms.Label label296;
        private System.Windows.Forms.Label label297;
        private System.Windows.Forms.Label label298;
        private System.Windows.Forms.Label label299;
        private System.Windows.Forms.Label label300;
        private System.Windows.Forms.Label label301;
        private System.Windows.Forms.Label label302;
        private System.Windows.Forms.Label label303;
        private System.Windows.Forms.Label label304;
        private System.Windows.Forms.Label label305;
        private System.Windows.Forms.Label label306;
        private System.Windows.Forms.Label label307;
        private System.Windows.Forms.Label label308;
        private System.Windows.Forms.Label label309;
        private System.Windows.Forms.Label label310;
        private System.Windows.Forms.Label label311;
        private System.Windows.Forms.Label label312;
        private System.Windows.Forms.Label label313;
        private System.Windows.Forms.Label label314;
        private System.Windows.Forms.Label label315;
        private System.Windows.Forms.Label label316;
        private System.Windows.Forms.Label label317;
        private System.Windows.Forms.Label label318;
        private System.Windows.Forms.Label label319;
        private System.Windows.Forms.Label label320;
        private System.Windows.Forms.Label label321;
        private System.Windows.Forms.Label label322;
        private System.Windows.Forms.Label label323;
        private System.Windows.Forms.Label label324;
        private System.Windows.Forms.Label label325;
        private System.Windows.Forms.Label label326;
        private System.Windows.Forms.Label label327;
        private System.Windows.Forms.Label label328;
        private System.Windows.Forms.Label label329;
        private System.Windows.Forms.Label label330;
        private System.Windows.Forms.Label label331;
        private System.Windows.Forms.Label label332;
        private System.Windows.Forms.Label label333;
        private System.Windows.Forms.Label label334;
        private System.Windows.Forms.Label label335;
        private System.Windows.Forms.Label label336;
        private System.Windows.Forms.Label label337;
        private System.Windows.Forms.Label label338;
        private System.Windows.Forms.Label label339;
        private System.Windows.Forms.Label label340;
        private System.Windows.Forms.Label label341;
        private System.Windows.Forms.Label label342;
        private System.Windows.Forms.Label label343;
        private System.Windows.Forms.Label label344;
        private System.Windows.Forms.Label label345;
        private System.Windows.Forms.Label label346;
        private System.Windows.Forms.Label label347;
        private System.Windows.Forms.Label label348;
        private System.Windows.Forms.Label label349;
        private System.Windows.Forms.Label label350;
        private System.Windows.Forms.Label label351;
        private System.Windows.Forms.Label label352;
        private System.Windows.Forms.Label label353;
        private System.Windows.Forms.Label label354;
        private System.Windows.Forms.Label label355;
        private System.Windows.Forms.Label label356;
        private System.Windows.Forms.Label label357;
        private System.Windows.Forms.Label label358;
        private System.Windows.Forms.Label label359;
        private System.Windows.Forms.Label label360;
        private System.Windows.Forms.Label label361;
        private System.Windows.Forms.Label label362;
        private System.Windows.Forms.Label label363;
        private System.Windows.Forms.Label label364;
        private System.Windows.Forms.Label label365;
        private System.Windows.Forms.Label label366;
        private System.Windows.Forms.Label label367;
        private System.Windows.Forms.Label label368;
        private System.Windows.Forms.Label label369;
        private System.Windows.Forms.Label label370;
        private System.Windows.Forms.Label label371;
        private System.Windows.Forms.Label label372;
        private System.Windows.Forms.Label label373;
        private System.Windows.Forms.Label label374;
        private System.Windows.Forms.Label label375;
        private System.Windows.Forms.Label label376;
        private System.Windows.Forms.Label label377;
        private System.Windows.Forms.Label label378;
        private System.Windows.Forms.Label label379;
        private System.Windows.Forms.Label label380;
        private System.Windows.Forms.Label label381;
        private System.Windows.Forms.Label label382;
        private System.Windows.Forms.Label label383;
        private System.Windows.Forms.Label label384;
        private System.Windows.Forms.Label label385;
        private System.Windows.Forms.Label label386;
        private System.Windows.Forms.Label label387;
        private System.Windows.Forms.Label label388;
        private System.Windows.Forms.Label label389;
        private System.Windows.Forms.Label label390;
        private System.Windows.Forms.Label label391;
        private System.Windows.Forms.Label label392;
        private System.Windows.Forms.Label label393;
        private System.Windows.Forms.Label label394;
        private System.Windows.Forms.Label label395;
        private System.Windows.Forms.Label label396;
        private System.Windows.Forms.Label label397;
        private System.Windows.Forms.Label label398;
        private System.Windows.Forms.Label label399;
        private System.Windows.Forms.Label label400;
        private System.Windows.Forms.Button btnup;
        private System.Windows.Forms.Button btnleft;
        private System.Windows.Forms.Button btnright;
        private System.Windows.Forms.Button btndown;
        private System.Windows.Forms.Label lbldanger;
        private System.Windows.Forms.Label lblstatus;
    }
}

